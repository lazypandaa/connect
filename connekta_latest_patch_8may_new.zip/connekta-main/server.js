// import express from 'express';
// import cors from 'cors';
// import axios from 'axios';
// import dotenv from 'dotenv';

// dotenv.config();

// const app = express();
// const PORT = 3001;

// // Enable CORS for all origins
// app.use(cors());

// // Middleware to parse JSON requests
// app.use(express.json());

// const API_KEY = process.env.REACT_APP_GEMINI_API_KEY;

// if (!API_KEY) {
//   console.error('API key is missing. Please check your .env file.');
//   process.exit(1);
// }

// console.log('Loaded API Key:', API_KEY);

// // Endpoint to list available models
// app.get('/api/models', async (req, res) => {
//   try {
//     const response = await axios.get(
//       `https://generativelanguage.googleapis.com/v1/models?key=${API_KEY}`
//     );
//     res.json(response.data);
//   } catch (error) {
//     console.error('Error fetching models:', error.response?.data || error.message);
//     res.status(500).json({ error: 'Failed to fetch models' });
//   }
// });

// // Endpoint to fetch a response from the Gemini model
// app.post('/api/chat', async (req, res) => {
//   const { message } = req.body;

//   if (!message) {
//     return res.status(400).json({ error: 'Message is required' });
//   }

//   try {
//     console.log('Sending request to:', `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-pro-001:generateText`);
//     console.log('Request body:', { prompt: { text: message } });

//     const response = await axios.post(
//       `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-pro-001:generateText?key=${API_KEY}`,
//       {
//         prompt: { text: message },
//       },
//       {
//         headers: { 'Content-Type': 'application/json' },
//       }
//     );

//     res.json(response.data);
//   } catch (error) {
//     console.error('Error fetching AI response:', error.response?.data || error.message);
//     res.status(500).json({ error: 'Failed to fetch AI response' });
//   }
// });

// // Start the server
// app.listen(PORT, () => {
//   console.log(`Server is running on http://localhost:${PORT}`);
// });

// server.js



// import express from 'express';
// import cors from 'cors';
// import axios from 'axios';
// import dotenv from 'dotenv';
// dotenv.config();

// const app = express();
// app.use(express.json());
// app.use(cors());

// const API_KEY = 'AIzaSyCuFOSSe87EW9VRtzurOaHT5iv4a7Y6sLU'; // Replace with your actual API key
// const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' + API_KEY;

// app.post('/api/chat', async (req, res) => {
//     try {
//         const response = await axios.post(API_URL, {
//             contents: [{
//                 parts: [{ text: req.body.prompt }]
//             }]
//         });
//         res.json(response.data);
//     } catch (error) {
//         console.error('Error calling Gemini API:', error);
//         res.status(500).json({ error: 'Failed to generate content' });
//     }
// });
// app.get('/test', (req, res) => {
//   res.send('Test route is working!');
// });

// const PORT = process.env.PORT || 3000;
// app.listen(PORT, () => {
//     console.log(`Server listening on port ${PORT}`);
// });


import express from 'express';
import cors from 'cors';
import axios from 'axios';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(express.json());
app.use(cors());

const API_KEY = 'AIzaSyBwtxJNI5iohtXmCfXZqTgupMBM7RKcEhU'; // Replace with your API key
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro-001:generateContent?key=${API_KEY}`;

app.post('/api/chat', async (req, res) => {
    try {
        const prompt = req.body.message;
        console.log("received prompt: ", prompt); // check to make sure the prompt is received.
        const response = await axios.post(API_URL, {
            contents: [{
                parts: [{ text: prompt }] // Correctly format the parts array
            }]
        });
        const aiResponse = response.data.candidates?.[0]?.content?.parts?.[0]?.text || "Gemini returned no text";
        res.json({ response: aiResponse });
    } catch (error) {
        console.error('Error calling Gemini API:', error);
        res.status(500).json({ error: 'Failed to generate content' });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});
