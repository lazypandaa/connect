import React from 'react';
import './../assets/css/Feed.css';
import Post from './Post';
import pawankalyan from './../assets/images/pawankalyan.jpeg';
import pawankalyan1 from './../assets/images/pawankalyan1.jpeg';
import salaar from './../assets/images/salaar.jpeg';
import threeman from './../assets/images/threeman.jpeg';

const Feed = () => {
  const avatars = [
    'https://i.pravatar.cc/150?img=1',
    'https://i.pravatar.cc/150?img=2',
    'https://i.pravatar.cc/150?img=3',
    'https://i.pravatar.cc/150?img=4'
  ];

  const posts = [
    {
      username: "john_doe",
      image: pawankalyan,
      caption: "Beautiful sunset!",
      avatar: avatars[0],
      initialLikes: 10,
      initialComments: 5,
      initialShares: 2
    },
    {
      username: "jane_smith",
      image: pawankalyan1,
      caption: "Had a great day at the beach!",
      avatar: avatars[1],
      initialLikes: 20,
      initialComments: 10,
      initialShares: 5
    },
    {
      username: "elon_musk",
      image: salaar,
      caption: "Excited for the new movie!",
      avatar: avatars[2],
      initialLikes: 30,
      initialComments: 15,
      initialShares: 8
    },
    {
      username: "mark_taylor",
      image: threeman,
      caption: "Just finished watching this movie!",
      avatar: avatars[3],
      initialLikes: 40,
      initialComments: 20,
      initialShares: 10
    }
  ];

  return (
    <div className="feed">
      <div className="feed-content">
        {posts.map((post, index) => (
          <div className="post-wrapper" key={index}>
            <Post 
              username={post.username} 
              image={post.image} 
              caption={post.caption} 
              avatar={post.avatar} 
              initialLikes={post.initialLikes} 
              initialComments={post.initialComments} 
              initialShares={post.initialShares} 
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Feed;