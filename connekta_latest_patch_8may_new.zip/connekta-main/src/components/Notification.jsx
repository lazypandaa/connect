import React from 'react'

function Notification() {
  return (
    <div>
        <h6 className='text-xl font-bold flex'>Notification:</h6>
        <div className='flex flex-col gap-2'>
            <div className='bg-gray-200 p-2 rounded-lg shadow-md'>
            <p className='text-sm'>You have a new message from John Doe</p>
            </div>
            <div className='bg-gray-200 p-2 rounded-lg shadow-md'>
            <p className='text-sm'>Your profile was updated successfully</p>
            </div>
            <div className='bg-gray-200 p-2 rounded-lg shadow-md'>
            <p className='text-sm'>You have a new follower: Jane Smith</p>
            </div>
        </div>

    </div>
  )
}

export default Notification