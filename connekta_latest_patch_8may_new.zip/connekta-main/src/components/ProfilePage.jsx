import React, { useEffect, useState } from "react";
import { FaUser, FaSchool, FaHome, FaHeart, FaUsers, FaUserPlus, FaUserMinus, FaUserCheck, FaUserTimes, FaSearch } from "react-icons/fa";
import krishna from "./../assets/images/krishna kalki.jpeg";
import pawankalyan from "./../assets/images/pawankalyan.jpeg";
import "./../assets/css/ProfilePage.css";
import axios from "axios";
import { useParams } from "react-router-dom";

const ProfileInfo = ({ profileData, friendsCount }) => {
  const [userName, setUserName] = useState('User');
  
  useEffect(() => {
    // If we have profile data from the API, use that
    if (profileData && profileData.fullname) {
      setUserName(profileData.fullname);
      return;
    }
    
    // Otherwise, fall back to localStorage
    const storedUserName = localStorage.getItem("userName");
    const storedUser = localStorage.getItem("user");
    
    if (storedUserName) {
      setUserName(storedUserName);
    } else if (storedUser) {
      try {
        const userObj = JSON.parse(storedUser);
        if (userObj.fullname || userObj.name || userObj.username) {
          setUserName(userObj.fullname || userObj.name || userObj.username);
        }
      } catch (e) {
        console.error("Error parsing user data:", e);
      }
    }
  }, [profileData]);

  console.log("Friends count in ProfileInfo:", friendsCount); // Debug log

  return (
    <div className="relative -mt-10 flex flex-row pl-20 gap-5 w-full shadow-sm">
      <div className="w-32 h-32 rounded-full overflow-hidden border border-white shadow-md">
        <img src={pawankalyan} alt="Profile" />
      </div>
      <div className="mt-10">
        <h2 className="text-xl font-semibold mt-2">{userName}</h2>
        <p className="text-gray-600 font-medium">{friendsCount} friends</p>
        <div className="flex space-x-2 mt-1 text-gray-500">
          <FaUser /> <FaUser /> <FaUser /> <FaUser /> <FaUser /> <FaUser />
        </div>
      </div>
    </div>
  );
};

const NavigationTabs = ({ activeTab, setActiveTab }) => (
  <div className="mt-4 border-t px-6 py-3 flex gap-10 justify-center text-gray-700">
    <button 
      className={`font-medium ${activeTab === 'posts' ? 'font-semibold text-orange-700 border-b-2 border-orange-700' : ''}`}
      onClick={() => setActiveTab('posts')}
    >
      Posts
    </button>
    <button 
      className={`font-medium ${activeTab === 'about' ? 'font-semibold text-orange-700 border-b-2 border-orange-700' : ''}`}
      onClick={() => setActiveTab('about')}
    >
      About
    </button>
    <button 
      className={`font-medium ${activeTab === 'friends' ? 'font-semibold text-orange-700 border-b-2 border-orange-700' : ''}`}
      onClick={() => setActiveTab('friends')}
    >
      Friends
    </button>
    <button 
      className={`font-medium ${activeTab === 'photos' ? 'font-semibold text-orange-700 border-b-2 border-orange-700' : ''}`}
      onClick={() => setActiveTab('photos')}
    >
      Photos
    </button>
    <button 
      className={`font-medium ${activeTab === 'videos' ? 'font-semibold text-orange-700 border-b-2 border-orange-700' : ''}`}
      onClick={() => setActiveTab('videos')}
    >
      Videos
    </button>
  </div>
);

const IntroSection = () => (
  <div className="w-full md:w-1/2 shadow-md p-4 rounded-lg">
    <h3 className="text-lg font-semibold">Intro</h3>
    <p className="text-gray-600 mt-1">Not Yet Working</p>
    <p className="flex items-center mt-1">
      <FaSchool className="mr-2" /> Studied at AANM & VVRSR Polytechnic
    </p>
    <p className="flex items-center mt-1">
      <FaSchool className="mr-2" /> Went to Kendriya Vidyalaya, Machilipatnam
    </p>
    <p className="flex items-center mt-1">
      <FaHome className="mr-2" /> Lives in Machilipatnam
    </p>
    <p className="flex items-center mt-1">
      <FaHome className="mr-2" /> From Machilipatnam
    </p>
    <p className="flex items-center mt-1">
      <FaHeart className="mr-2 text-red-500" /> In a relationship
    </p>
    <p className="flex items-center mt-1">
      <FaUsers className="mr-2" /> Followed by 149 people
    </p>
  </div>
);

const PhotosSection = ({ posts }) => {
  const handlePhotoClick = (mediaPath) => {
    console.log(`Image URL: http://localhost:8080/${mediaPath}`);
  };

  return (
    <div className="w-full md:w-1/2 shadow-md p-4 rounded-lg overflow-y-auto photos-section" style={{ maxHeight: '400px' }}>
      <h3 className="text-lg font-semibold">Photos</h3>
      <div className="flex flex-wrap gap-2 mt-2">
        {posts.length === 0 ? (
          <p className="text-gray-500">No posts yet.</p>
        ) : (
          posts.map((post, index) => (
            <div
              key={index}
              className="w-32 h-32 bg-gray-200 rounded-lg overflow-hidden cursor-pointer"
              onClick={() => handlePhotoClick(post.mediaPath)}
            >
              <img
                src={`http://localhost:8080/${post.mediaPath}`}
                alt={`post-${index}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const FriendsSection = ({ isCurrentUser }) => {
  const [friends, setFriends] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      setError("Please log in to view friends");
      setLoading(false);
      return;
    }

    const fetchFriends = async () => {
      try {
        // Fetch friends list
        const response = await axios.post(
          'http://localhost:8080/friends/get-friends', 
          { csrid: token }
        );
        
        if (response.data.status === 'success') {
          setFriends(response.data.friends || []);
        } else {
          setError(response.data.message || "Failed to load friends");
        }

        // If this is the current user's profile, fetch pending requests too
        if (isCurrentUser) {
          const pendingResponse = await axios.post(
            'http://localhost:8080/friends/pending-requests',
            { csrid: token }
          );
          
          if (pendingResponse.data.status === 'success') {
            setPendingRequests(pendingResponse.data.requests || []);
          }
        }
        
        setLoading(false);
      } catch (err) {
        console.error("Error fetching friends data:", err);
        setError("Failed to load friends data");
        setLoading(false);
      }
    };

    fetchFriends();
  }, [isCurrentUser]);

  const handleSearchUsers = async () => {
    if (!searchQuery.trim()) return;
    
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        'http://localhost:8080/friends/search-users',
        { 
          csrid: token,
          query: searchQuery 
        }
      );
      
      if (response.data.status === 'success') {
        setSearchResults(response.data.users || []);
      } else {
        console.error("Search failed:", response.data.message);
      }
    } catch (err) {
      console.error("Error searching users:", err);
    }
  };

  const handleSendFriendRequest = async (userId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        'http://localhost:8080/friends/send-request',
        { 
          csrid: token,
          receiverId: userId 
        }
      );
      
      if (response.data.status === 'success') {
        // Update the search results to show the request was sent
        setSearchResults(prev => 
          prev.map(user => 
            user.id === userId ? { ...user, requestSent: true } : user
          )
        );
      } else {
        console.error("Failed to send request:", response.data.message);
      }
    } catch (err) {
      console.error("Error sending friend request:", err);
    }
  };

  const handleAcceptFriendRequest = async (requestId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        'http://localhost:8080/friends/accept-request',
        { 
          csrid: token,
          requestId: requestId 
        }
      );
      
      if (response.data.status === 'success') {
        // Remove from pending requests
        const acceptedRequest = pendingRequests.find(req => req.id === requestId);
        setPendingRequests(prev => prev.filter(req => req.id !== requestId));
        
        // Add to friends list if we have the sender data
        if (acceptedRequest && acceptedRequest.sender) {
          setFriends(prev => [...prev, acceptedRequest.sender]);
        } else {
          // Refresh friends list
          const friendsResponse = await axios.post(
            'http://localhost:8080/friends/get-friends', 
            { csrid: token }
          );
          
          if (friendsResponse.data.status === 'success') {
            setFriends(friendsResponse.data.friends || []);
          }
        }
      } else {
        console.error("Failed to accept request:", response.data.message);
      }
    } catch (err) {
      console.error("Error accepting friend request:", err);
    }
  };

  const handleRejectFriendRequest = async (requestId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        'http://localhost:8080/friends/reject-request',
        { 
          csrid: token,
          requestId: requestId 
        }
      );
      
      if (response.data.status === 'success') {
        // Remove from pending requests
        setPendingRequests(prev => prev.filter(req => req.id !== requestId));
      } else {
        console.error("Failed to reject request:", response.data.message);
      }
    } catch (err) {
      console.error("Error rejecting friend request:", err);
    }
  };

  const handleRemoveFriend = async (friendId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        'http://localhost:8080/friends/remove-friend',
        { 
          csrid: token,
          friendId: friendId 
        }
      );
      
      if (response.data.status === 'success') {
        // Remove from friends list
        setFriends(prev => prev.filter(friend => friend.id !== friendId));
      } else {
        console.error("Failed to remove friend:", response.data.message);
      }
    } catch (err) {
      console.error("Error removing friend:", err);
    }
  };

  if (loading) return <div className="w-full p-4 text-center">Loading friends...</div>;
  if (error) return <div className="w-full p-4 text-center text-red-500">{error}</div>;

  return (
    <div className="w-full shadow-md p-4 rounded-lg">
      <h3 className="text-lg font-semibold mb-4">Friends ({friends.length})</h3>
      
      {isCurrentUser && (
        <>
          <div className="mb-6">
            <div className="flex items-center mb-4">
              <input
                type="text"
                placeholder="Search for new friends..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-grow p-2 border border-gray-300 rounded-l-lg"
              />
              <button 
                onClick={handleSearchUsers}
                className="bg-orange-600 hover:bg-orange-700 text-white p-2 rounded-r-lg"
              >
                <FaSearch />
              </button>
            </div>
            
            {searchResults.length > 0 && (
              <div className="mb-4">
                <h4 className="text-md font-medium mb-2">Search Results</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {searchResults.map((user) => (
                    <div key={user.id} className="border p-3 rounded-lg flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-gray-300 mr-3">
                          {/* User avatar placeholder */}
                        </div>
                        <div>
                          <p className="font-medium">{user.fullname}</p>
                          <p className="text-sm text-gray-600">{user.email}</p>
                        </div>
                      </div>
                      
                      <button
                        disabled={user.requestSent}
                        onClick={() => handleSendFriendRequest(user.id)}
                        className={`p-2 rounded-full ${
                          user.requestSent 
                            ? 'bg-gray-200 text-gray-500' 
                            : 'bg-orange-100 text-orange-600 hover:bg-orange-200'
                        }`}
                        title={user.requestSent ? "Request sent" : "Send friend request"}
                      >
                        {user.requestSent ? <FaUserCheck /> : <FaUserPlus />}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {pendingRequests.length > 0 && (
              <div className="mb-6">
                <h4 className="text-md font-medium mb-2">Friend Requests ({pendingRequests.length})</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {pendingRequests.map((request) => (
                    <div key={request.id} className="border p-3 rounded-lg flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-gray-300 mr-3">
                          {/* Sender avatar placeholder */}
                        </div>
                        <div>
                          <p className="font-medium">{request.sender.fullname}</p>
                          <p className="text-sm text-gray-600">{request.sender.email}</p>
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleAcceptFriendRequest(request.id)}
                          className="p-2 rounded-full bg-green-100 text-green-600 hover:bg-green-200"
                          title="Accept request"
                        >
                          <FaUserCheck />
                        </button>
                        <button
                          onClick={() => handleRejectFriendRequest(request.id)}
                          className="p-2 rounded-full bg-red-100 text-red-600 hover:bg-red-200"
                          title="Reject request"
                        >
                          <FaUserTimes />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </>
      )}
      
      <div className="friends-grid grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {friends.length === 0 ? (
          <p className="col-span-full text-gray-500 text-center">No friends yet.</p>
        ) : (
          friends.map((friend) => (
            <div key={friend.id} className="friend-card bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 rounded-full bg-gray-200 mb-3 overflow-hidden">
                  {/* We would use a real avatar here, but for now it's a placeholder */}
                  <img 
                    src={`https://i.pravatar.cc/150?u=${friend.id}`} 
                    alt={friend.fullname}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h4 className="font-medium text-center">{friend.fullname}</h4>
                
                {isCurrentUser && (
                  <button
                    onClick={() => handleRemoveFriend(friend.id)}
                    className="mt-2 text-sm text-gray-500 hover:text-red-500 flex items-center gap-1"
                  >
                    <FaUserMinus /> <span>Remove</span>
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const ContentTabs = ({ activeTab, userPosts }) => {
  switch(activeTab) {
    case 'about':
      return <IntroSection />;
    case 'friends':
      return <FriendsSection isCurrentUser={true} />;
    case 'photos':
      return <PhotosSection posts={userPosts.filter(post => post.mediaPath)} />;
    case 'videos':
      return <div className="w-full p-4">Videos section coming soon</div>;
    case 'posts':
    default:
      return (
        <div className="flex flex-col md:flex-row gap-6 w-full">
          <IntroSection />
          <PhotosSection posts={userPosts} />
        </div>
      );
  }
};

export default function ProfilePage() {
  const [userPosts, setUserPosts] = useState([]);
  const [profileData, setProfileData] = useState(null);
  const [activeTab, setActiveTab] = useState('posts');
  const [friendsCount, setFriendsCount] = useState(0);
  const { userId } = useParams();  // Get userId from URL if available
  
  // Use current user ID if no userId specified in URL
  const profileUserId = userId || localStorage.getItem('userId') || 1;  // Get userId from localStorage or default to 1
  const isCurrentUserProfile = !userId; // If no userId in URL, we're viewing current user's profile

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        // Fetch user profile data
        const profileRes = await axios.get(`http://localhost:8080/api/users/${profileUserId}`);
        setProfileData(profileRes.data);
        
        // Fetch user posts
        const postsRes = await axios.get(`http://localhost:8080/api/posts/user/${profileUserId}`);
        setUserPosts(postsRes.data);
        
        // Fetch friends count
        const token = localStorage.getItem('token');
        if (token) {
          console.log("Fetching friends with token:", token); // Debug log
          const friendsRes = await axios.post(
            'http://localhost:8080/friends/get-friends', 
            { csrid: token }
          );
          
          console.log("Friends API response:", friendsRes.data); // Debug log
          
          if (friendsRes.data.status === 'success') {
            setFriendsCount(friendsRes.data.friends?.length || 0);
          }
        }
      } catch (err) {
        console.error("Failed to fetch user data", err);
      }
    };

    fetchUserData();
  }, [profileUserId]);

  return (
    <div className="profilePage bg-gray-100 flex flex-col items-center justify-center h-screen overflow-y-auto">
      <div className="bg-white shadow-lg rounded-lg w-full">
        {/* Cover Photo */}
        <div className="h-96 w-full overflow-hidden rounded-t-lg mt-60">
          <img src={krishna} alt="Cover" className="w-full h-full object-cover" />
        </div>

        {/* Profile Info */}
        <ProfileInfo profileData={profileData} friendsCount={friendsCount} />
        
        {/* Navigation Tabs */}
        <NavigationTabs activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Content based on active tab */}
        <div className="p-6">
          <ContentTabs activeTab={activeTab} userPosts={userPosts} />
        </div>
      </div>
    </div>
  );
}
