package klu.com.service;

import klu.com.model.ChatMessage;
import klu.com.repository.ChatMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class ChatMessageService {
    
    @Autowired
    private ChatMessageRepository chatMessageRepository;
    
    /**
     * Get messages between two users
     */
    public List<Map<String, Object>> getMessagesBetweenUsers(Long userId, Long friendId) {
        List<ChatMessage> messages = chatMessageRepository.findMessagesBetweenUsers(userId, friendId);
        List<Map<String, Object>> formattedMessages = new ArrayList<>();
        
        for (ChatMessage message : messages) {
            Map<String, Object> formattedMessage = new HashMap<>();
            formattedMessage.put("id", message.getId());
            formattedMessage.put("message_text", message.getMessageText());
            formattedMessage.put("read_status", message.getReadStatus());
            formattedMessage.put("receiver_id", message.getReceiverId());
            formattedMessage.put("sender_id", message.getSenderId());
            formattedMessage.put("timestamp", message.getTimestamp());
            
            formattedMessages.add(formattedMessage);
        }
        
        return formattedMessages;
    }
    
    /**
     * Send a new message
     */
    public Map<String, Object> sendMessage(String messageText, int readStatus, Long receiverId, 
                                          Long senderId, String timestampStr) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            LocalDateTime timestamp;
            if (timestampStr != null && !timestampStr.isEmpty()) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                timestamp = LocalDateTime.parse(timestampStr, formatter);
            } else {
                timestamp = LocalDateTime.now();
            }
            
            ChatMessage message = new ChatMessage(
                messageText,
                readStatus,
                receiverId,
                senderId,
                timestamp
            );
            
            ChatMessage savedMessage = chatMessageRepository.save(message);
            
            response.put("status", "success");
            response.put("message", "Message sent successfully");
            response.put("messageId", savedMessage.getId());
        } catch (Exception e) {
            e.printStackTrace();
            response.put("status", "error");
            response.put("message", "Failed to send message: " + e.getMessage());
        }
        
        return response;
    }
    
    /**
     * Mark messages as read
     */
    public Map<String, Object> markMessagesAsRead(Long receiverId, Long senderId) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            int updatedCount = chatMessageRepository.markMessagesAsRead(senderId, receiverId);
            
            response.put("status", "success");
            response.put("message", "Messages marked as read");
            response.put("updatedCount", updatedCount);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "Failed to mark messages as read: " + e.getMessage());
        }
        
        return response;
    }
}
