package klu.com.repository;

import klu.com.model.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
    
    /**
     * Find all messages between two users
     */
    @Query("SELECT m FROM ChatMessage m WHERE (m.senderId = :userId AND m.receiverId = :friendId) OR (m.senderId = :friendId AND m.receiverId = :userId) ORDER BY m.timestamp ASC")
    List<ChatMessage> findMessagesBetweenUsers(@Param("userId") Long userId, @Param("friendId") Long friendId);
    
    /**
     * Find unread messages sent to a specific user
     */
    List<ChatMessage> findByReceiverIdAndReadStatus(Long receiverId, int readStatus);
    
    /**
     * Mark messages as read
     */
    @Query("UPDATE ChatMessage m SET m.readStatus = 1 WHERE m.senderId = :senderId AND m.receiverId = :receiverId AND m.readStatus = 0")
    int markMessagesAsRead(@Param("senderId") Long senderId, @Param("receiverId") Long receiverId);
}
