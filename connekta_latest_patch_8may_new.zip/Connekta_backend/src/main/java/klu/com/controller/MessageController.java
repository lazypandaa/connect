package klu.com.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import klu.com.model.ChatMessage;
import klu.com.service.ChatMessageService;
import klu.com.model.JWTManager;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api")
public class MessageController {
    
    @Autowired
    private ChatMessageService chatMessageService;
    
    @Autowired
    private JWTManager jwtManager;
    
    /**
     * Get messages between two users
     */
    @PostMapping("/messages")
    public List<Map<String, Object>> getMessages(@RequestBody Map<String, Object> request) {
        String token = (String) request.get("csrid");
        Long userId = Long.valueOf(request.get("userId").toString());
        Long friendId = Long.valueOf(request.get("friendId").toString());
        
        String email = jwtManager.validateToken(token);
        if (email.equals("401")) {
            return List.of();
        }
        
        return chatMessageService.getMessagesBetweenUsers(userId, friendId);
    }
    
    /**
     * Send a new message
     */
    @PostMapping("/send-message")
    public Map<String, Object> sendMessage(@RequestBody Map<String, Object> request) {
        String token = (String) request.get("csrid");
        Long senderId = Long.valueOf(request.get("sender_id").toString());
        Long receiverId = Long.valueOf(request.get("receiver_id").toString());
        String messageText = (String) request.get("message_text");
        
        String email = jwtManager.validateToken(token);
        if (email.equals("401")) {
            return Map.of(
                "status", "error",
                "message", "Invalid token"
            );
        }
        
        return chatMessageService.sendMessage(senderId, receiverId, messageText);
    }
}
