package klu.com.model;

import klu.com.repository.FriendsRepository;
import klu.com.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FriendsManager {

    @Autowired
    private FriendsRepository friendsRepository;
    
    @Autowired
    private UsersRepository usersRepository;
    
    @Autowired
    private JWTManager jwtManager;

    /**
     * Send a friend request from one user to another
     */
    public Map<String, Object> sendFriendRequest(String token, Long receiverId) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String senderEmail = jwtManager.validateToken(token);
        if (senderEmail.equals("401")) {
            response.put("status", "error");
            response.put("message", "Invalid or expired token");
            return response;
        }
        
        // Get sender user
        Optional<Users> senderOpt = usersRepository.findByEmail(senderEmail);
        if (senderOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "Sender user not found");
            return response;
        }
        
        // Get receiver user
        Optional<Users> receiverOpt = usersRepository.findById(receiverId);
        if (receiverOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "Receiver user not found");
            return response;
        }
        
        Users sender = senderOpt.get();
        Users receiver = receiverOpt.get();
        
        // Check if users are the same
        if (sender.getId().equals(receiver.getId())) {
            response.put("status", "error");
            response.put("message", "Cannot send friend request to yourself");
            return response;
        }
        
        // Check if friendship already exists
        Optional<Friends> existingFriendship = friendsRepository.findFriendship(sender, receiver);
        if (existingFriendship.isPresent()) {
            Friends friendship = existingFriendship.get();
            switch (friendship.getStatus()) {
                case "accepted":
                    response.put("status", "error");
                    response.put("message", "Users are already friends");
                    break;
                case "pending":
                    if (friendship.getSender().getId().equals(sender.getId())) {
                        response.put("status", "error");
                        response.put("message", "Friend request already sent");
                    } else {
                        // If the other user already sent a request, accept it
                        friendship.setStatus("accepted");
                        friendsRepository.save(friendship);
                        response.put("status", "success");
                        response.put("message", "Friend request accepted");
                    }
                    break;
                case "rejected":
                    // Allow sending request again if previously rejected
                    friendship.setSender(sender);
                    friendship.setReceiver(receiver);
                    friendship.setStatus("pending");
                    friendsRepository.save(friendship);
                    response.put("status", "success");
                    response.put("message", "Friend request sent");
                    break;
                case "blocked":
                    response.put("status", "error");
                    response.put("message", "Cannot send friend request to this user");
                    break;
                default:
                    response.put("status", "error");
                    response.put("message", "Invalid friendship status");
            }
            return response;
        }
        
        // Create new friend request
        Friends newFriendship = new Friends(sender, receiver, "pending");
        friendsRepository.save(newFriendship);
        
        response.put("status", "success");
        response.put("message", "Friend request sent successfully");
        return response;
    }
    
    /**
     * Accept a friend request
     */
    public Map<String, Object> acceptFriendRequest(String token, Long requestId) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String userEmail = jwtManager.validateToken(token);
        if (userEmail.equals("401")) {
            response.put("status", "error");
            response.put("message", "Invalid or expired token");
            return response;
        }
        
        // Get user
        Optional<Users> userOpt = usersRepository.findByEmail(userEmail);
        if (userOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "User not found");
            return response;
        }
        
        // Get friend request
        Optional<Friends> friendshipOpt = friendsRepository.findById(requestId);
        if (friendshipOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "Friend request not found");
            return response;
        }
        
        Friends friendship = friendshipOpt.get();
        Users user = userOpt.get();
        
        // Check if this user is the receiver of the request
        if (!friendship.getReceiver().getId().equals(user.getId())) {
            response.put("status", "error");
            response.put("message", "Cannot accept this friend request");
            return response;
        }
        
        // Check if request is pending
        if (!friendship.getStatus().equals("pending")) {
            response.put("status", "error");
            response.put("message", "This friend request cannot be accepted (status: " + friendship.getStatus() + ")");
            return response;
        }
        
        // Accept the request
        friendship.setStatus("accepted");
        friendsRepository.save(friendship);
        
        response.put("status", "success");
        response.put("message", "Friend request accepted successfully");
        return response;
    }
    
    /**
     * Reject a friend request
     */
    public Map<String, Object> rejectFriendRequest(String token, Long requestId) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String userEmail = jwtManager.validateToken(token);
        if (userEmail.equals("401")) {
            response.put("status", "error");
            response.put("message", "Invalid or expired token");
            return response;
        }
        
        // Get user
        Optional<Users> userOpt = usersRepository.findByEmail(userEmail);
        if (userOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "User not found");
            return response;
        }
        
        // Get friend request
        Optional<Friends> friendshipOpt = friendsRepository.findById(requestId);
        if (friendshipOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "Friend request not found");
            return response;
        }
        
        Friends friendship = friendshipOpt.get();
        Users user = userOpt.get();
        
        // Check if this user is the receiver of the request
        if (!friendship.getReceiver().getId().equals(user.getId())) {
            response.put("status", "error");
            response.put("message", "Cannot reject this friend request");
            return response;
        }
        
        // Check if request is pending
        if (!friendship.getStatus().equals("pending")) {
            response.put("status", "error");
            response.put("message", "This friend request cannot be rejected (status: " + friendship.getStatus() + ")");
            return response;
        }
        
        // Reject the request
        friendship.setStatus("rejected");
        friendsRepository.save(friendship);
        
        response.put("status", "success");
        response.put("message", "Friend request rejected successfully");
        return response;
    }
    
    /**
     * Remove a friend
     */
    public Map<String, Object> removeFriend(String token, Long friendId) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String userEmail = jwtManager.validateToken(token);
        if (userEmail.equals("401")) {
            response.put("status", "error");
            response.put("message", "Invalid or expired token");
            return response;
        }
        
        // Get user
        Optional<Users> userOpt = usersRepository.findByEmail(userEmail);
        if (userOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "User not found");
            return response;
        }
        
        // Get friend
        Optional<Users> friendOpt = usersRepository.findById(friendId);
        if (friendOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "Friend user not found");
            return response;
        }
        
        Users user = userOpt.get();
        Users friend = friendOpt.get();
        
        // Check if they are friends
        Optional<Friends> friendshipOpt = friendsRepository.findFriendship(user, friend);
        if (friendshipOpt.isEmpty() || !friendshipOpt.get().getStatus().equals("accepted")) {
            response.put("status", "error");
            response.put("message", "Users are not friends");
            return response;
        }
        
        // Remove friendship
        friendsRepository.delete(friendshipOpt.get());
        
        response.put("status", "success");
        response.put("message", "Friend removed successfully");
        return response;
    }
    
    /**
     * Block a user
     */
    public Map<String, Object> blockUser(String token, Long userId) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String blockerEmail = jwtManager.validateToken(token);
        if (blockerEmail.equals("401")) {
            response.put("status", "error");
            response.put("message", "Invalid or expired token");
            return response;
        }
        
        // Get blocker user
        Optional<Users> blockerOpt = usersRepository.findByEmail(blockerEmail);
        if (blockerOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "User not found");
            return response;
        }
        
        // Get target user
        Optional<Users> targetOpt = usersRepository.findById(userId);
        if (targetOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "Target user not found");
            return response;
        }
        
        Users blocker = blockerOpt.get();
        Users target = targetOpt.get();
        
        // Check if users are the same
        if (blocker.getId().equals(target.getId())) {
            response.put("status", "error");
            response.put("message", "Cannot block yourself");
            return response;
        }
        
        // Check if a relationship exists
        Optional<Friends> relationshipOpt = friendsRepository.findFriendship(blocker, target);
        
        if (relationshipOpt.isPresent()) {
            Friends relationship = relationshipOpt.get();
            // Set blocker as sender for consistency in blocked relationships
            relationship.setSender(blocker);
            relationship.setReceiver(target);
            relationship.setStatus("blocked");
            friendsRepository.save(relationship);
        } else {
            // Create new blocked relationship
            Friends blockedRelationship = new Friends(blocker, target, "blocked");
            friendsRepository.save(blockedRelationship);
        }
        
        response.put("status", "success");
        response.put("message", "User blocked successfully");
        return response;
    }
    
    /**
     * Unblock a user
     */
    public Map<String, Object> unblockUser(String token, Long userId) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String unblockerEmail = jwtManager.validateToken(token);
        if (unblockerEmail.equals("401")) {
            response.put("status", "error");
            response.put("message", "Invalid or expired token");
            return response;
        }
        
        // Get unblocker user
        Optional<Users> unblockerOpt = usersRepository.findByEmail(unblockerEmail);
        if (unblockerOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "User not found");
            return response;
        }
        
        // Get target user
        Optional<Users> targetOpt = usersRepository.findById(userId);
        if (targetOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "Target user not found");
            return response;
        }
        
        Users unblocker = unblockerOpt.get();
        Users target = targetOpt.get();
        
        // Check if relationship exists and is blocked
        Optional<Friends> relationshipOpt = friendsRepository.findBySenderAndReceiver(unblocker, target);
        if (relationshipOpt.isEmpty() || !relationshipOpt.get().getStatus().equals("blocked")) {
            response.put("status", "error");
            response.put("message", "This user is not blocked");
            return response;
        }
        
        // Remove the blocked relationship
        friendsRepository.delete(relationshipOpt.get());
        
        response.put("status", "success");
        response.put("message", "User unblocked successfully");
        return response;
    }
    
    /**
     * Get all friends of current user
     */
    public Map<String, Object> getFriends(String token) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String userEmail = jwtManager.validateToken(token);
        if (userEmail.equals("401")) {
            response.put("status", "error");
            response.put("message", "Invalid or expired token");
            return response;
        }
        
        // Get user
        Optional<Users> userOpt = usersRepository.findByEmail(userEmail);
        if (userOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "User not found");
            return response;
        }
        
        Users user = userOpt.get();
        
        // Get friends
        List<Users> friends = friendsRepository.findAllFriends(user);
        
        // Format friend data
        List<Map<String, Object>> friendsData = friends.stream()
            .map(friend -> {
                Map<String, Object> friendData = new HashMap<>();
                friendData.put("id", friend.getId());
                friendData.put("fullname", friend.getFullname());
                friendData.put("email", friend.getEmail());
                // Don't include password
                return friendData;
            })
            .collect(Collectors.toList());
        
        response.put("status", "success");
        response.put("friends", friendsData);
        return response;
    }
    
    /**
     * Get all pending friend requests received by current user
     */
    public Map<String, Object> getPendingRequests(String token) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String userEmail = jwtManager.validateToken(token);
        if (userEmail.equals("401")) {
            response.put("status", "error");
            response.put("message", "Invalid or expired token");
            return response;
        }
        
        // Get user
        Optional<Users> userOpt = usersRepository.findByEmail(userEmail);
        if (userOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "User not found");
            return response;
        }
        
        Users user = userOpt.get();
        
        // Get pending requests
        List<Friends> pendingRequests = friendsRepository.findByReceiverAndStatus(user, "pending");
        
        // Format request data
        List<Map<String, Object>> requestsData = pendingRequests.stream()
            .map(request -> {
                Map<String, Object> requestData = new HashMap<>();
                requestData.put("id", request.getId());
                requestData.put("sender", Map.of(
                    "id", request.getSender().getId(),
                    "fullname", request.getSender().getFullname(),
                    "email", request.getSender().getEmail()
                ));
                requestData.put("createdAt", request.getCreatedAt().toString());
                return requestData;
            })
            .collect(Collectors.toList());
        
        response.put("status", "success");
        response.put("requests", requestsData);
        return response;
    }
    
    /**
     * Get all sent friend requests by current user
     */
    public Map<String, Object> getSentRequests(String token) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String userEmail = jwtManager.validateToken(token);
        if (userEmail.equals("401")) {
            response.put("status", "error");
            response.put("message", "Invalid or expired token");
            return response;
        }
        
        // Get user
        Optional<Users> userOpt = usersRepository.findByEmail(userEmail);
        if (userOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "User not found");
            return response;
        }
        
        Users user = userOpt.get();
        
        // Get sent requests
        List<Friends> sentRequests = friendsRepository.findBySenderAndStatus(user, "pending");
        
        // Format request data
        List<Map<String, Object>> requestsData = sentRequests.stream()
            .map(request -> {
                Map<String, Object> requestData = new HashMap<>();
                requestData.put("id", request.getId());
                requestData.put("receiver", Map.of(
                    "id", request.getReceiver().getId(),
                    "fullname", request.getReceiver().getFullname(),
                    "email", request.getReceiver().getEmail()
                ));
                requestData.put("createdAt", request.getCreatedAt().toString());
                return requestData;
            })
            .collect(Collectors.toList());
        
        response.put("status", "success");
        response.put("requests", requestsData);
        return response;
    }
    
    /**
     * Search for users who are not already friends with current user
     */
    public Map<String, Object> searchUsers(String token, String query) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String userEmail = jwtManager.validateToken(token);
        if (userEmail.equals("401")) {
            response.put("status", "error");
            response.put("message", "Invalid or expired token");
            return response;
        }
        
        // Get current user
        Optional<Users> currentUserOpt = usersRepository.findByEmail(userEmail);
        if (currentUserOpt.isEmpty()) {
            response.put("status", "error");
            response.put("message", "User not found");
            return response;
        }
        
        Users currentUser = currentUserOpt.get();
        
        // Get all users that match the query
        // This is a simplified search - in production you might want more complex logic
        List<Users> allUsers = usersRepository.findByFullnameContainingIgnoreCase(query);
        
        // Get current user's friends
        List<Users> friends = friendsRepository.findAllFriends(currentUser);
        
        // Filter out current user and existing friends
        List<Map<String, Object>> filteredUsers = allUsers.stream()
            .filter(user -> !user.getId().equals(currentUser.getId()) && !friends.contains(user))
            .map(user -> {
                Map<String, Object> userData = new HashMap<>();
                userData.put("id", user.getId());
                userData.put("fullname", user.getFullname());
                userData.put("email", user.getEmail());
                // Check if there's a pending request
                Optional<Friends> pendingRequest = friendsRepository.findBySenderAndReceiver(currentUser, user);
                userData.put("requestSent", pendingRequest.isPresent() && "pending".equals(pendingRequest.get().getStatus()));
                return userData;
            })
            .collect(Collectors.toList());
        
        response.put("status", "success");
        response.put("users", filteredUsers);
        return response;
    }
}
