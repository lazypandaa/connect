import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faFilter, faUser, faBriefcase, faMapMarkerAlt, faGraduationCap, faTimes } from '@fortawesome/free-solid-svg-icons';
import '../assets/css/Searching.css';

// Mock data for demonstration
const mockUsers = [
  {
    id: 1,
    name: 'Alex Johnson',
    profession: 'Software Engineer',
    location: 'San Francisco, CA',
    education: 'Stanford University',
    skills: ['JavaScript', 'React', 'Node.js'],
    connections: 543,
    profileImage: 'https://randomuser.me/api/portraits/men/32.jpg',
  },
  {
    id: 2,
    name: 'Sophia Williams',
    profession: 'UX Designer',
    location: 'New York, NY',
    education: 'Rhode Island School of Design',
    skills: ['UI/UX', 'Figma', 'Adobe XD'],
    connections: 326,
    profileImage: 'https://randomuser.me/api/portraits/women/44.jpg',
  },
  {
    id: 3,
    name: 'Michael Chen',
    profession: 'Data Scientist',
    location: 'Boston, MA',
    education: 'MIT',
    skills: ['Python', 'Machine Learning', 'Data Analysis'],
    connections: 287,
    profileImage: 'https://randomuser.me/api/portraits/men/22.jpg',
  },
  {
    id: 4,
    name: 'Priya Patel',
    profession: 'Marketing Manager',
    location: 'Chicago, IL',
    education: 'Northwestern University',
    skills: ['Digital Marketing', 'Content Strategy', 'SEO'],
    connections: 412,
    profileImage: 'https://randomuser.me/api/portraits/women/65.jpg',
  },
  {
    id: 5,
    name: 'James Wilson',
    profession: 'Full Stack Developer',
    location: 'Austin, TX',
    education: 'University of Texas',
    skills: ['React', 'MongoDB', 'Express', 'TypeScript'],
    connections: 198,
    profileImage: 'https://randomuser.me/api/portraits/men/42.jpg',
  },
  {
    id: 6,
    name: 'Olivia Martinez',
    profession: 'Product Manager',
    location: 'Seattle, WA',
    education: 'University of Washington',
    skills: ['Product Development', 'Agile', 'User Research'],
    connections: 375,
    profileImage: 'https://randomuser.me/api/portraits/women/28.jpg',
  }
];

const Searching = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState(mockUsers);
  const [filters, setFilters] = useState({
    profession: '',
    location: '',
    education: ''
  });
  const [showFilters, setShowFilters] = useState(false);

  // Handle search input changes
  const handleSearchChange = (e) => {
    const term = e.target.value;
    setSearchTerm(term);
    
    if (!term.trim()) {
      setSearchResults(mockUsers);
      return;
    }
    
    // Filter users based on search term
    const filtered = mockUsers.filter(user => 
      user.name.toLowerCase().includes(term.toLowerCase()) ||
      user.profession.toLowerCase().includes(term.toLowerCase()) ||
      user.skills.some(skill => skill.toLowerCase().includes(term.toLowerCase()))
    );
    
    setSearchResults(filtered);
  };

  // Handle filter changes
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({
      ...filters,
      [name]: value
    });
    
    // Apply filters
    applyFilters(searchTerm, { ...filters, [name]: value });
  };

  // Apply filters to search results
  const applyFilters = (term, currentFilters) => {
    let results = mockUsers;
    
    // Apply search term filter
    if (term) {
      results = results.filter(user => 
        user.name.toLowerCase().includes(term.toLowerCase()) ||
        user.profession.toLowerCase().includes(term.toLowerCase()) ||
        user.skills.some(skill => skill.toLowerCase().includes(term.toLowerCase()))
      );
    }
    
    // Apply other filters
    if (currentFilters.profession) {
      results = results.filter(user => 
        user.profession.toLowerCase().includes(currentFilters.profession.toLowerCase())
      );
    }
    
    if (currentFilters.location) {
      results = results.filter(user => 
        user.location.toLowerCase().includes(currentFilters.location.toLowerCase())
      );
    }
    
    if (currentFilters.education) {
      results = results.filter(user => 
        user.education.toLowerCase().includes(currentFilters.education.toLowerCase())
      );
    }
    
    setSearchResults(results);
  };

  // Clear all filters
  const clearFilters = () => {
    setFilters({
      profession: '',
      location: '',
      education: ''
    });
    
    // Reset to original search results based only on search term
    if (searchTerm) {
      const filtered = mockUsers.filter(user => 
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.profession.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()))
      );
      setSearchResults(filtered);
    } else {
      setSearchResults(mockUsers);
    }
  };

  // Connect with user
  const connectWithUser = (userId) => {
    console.log(`Connecting with user ${userId}`);
    // Implementation would go here
  };

  return (
    <div className="search-page">
      <div className="search-container">
        <div className="search-header">
          <h1>Find People & Opportunities</h1>
          <p>Connect with professionals in your field</p>
        </div>
        
        <div className="search-bar-container">
          <div className="search-bar">
            <FontAwesomeIcon icon={faSearch} className="search-icon" />
            <input
              type="text"
              placeholder="Search for people, skills, or professions..."
              value={searchTerm}
              onChange={handleSearchChange}
              className="search-input"
            />
            <button 
              className="filter-button"
              onClick={() => setShowFilters(!showFilters)}
            >
              <FontAwesomeIcon icon={faFilter} />
              <span>Filters</span>
            </button>
          </div>
          
          {showFilters && (
            <div className="filters-panel">
              <div className="filter-header">
                <h3>Refine your search</h3>
                <button onClick={clearFilters} className="clear-filters-btn">
                  Clear all
                </button>
              </div>
              
              <div className="filter-group">
                <div className="filter-item">
                  <label>
                    <FontAwesomeIcon icon={faBriefcase} />
                    <span>Profession</span>
                  </label>
                  <input
                    type="text"
                    name="profession"
                    value={filters.profession}
                    onChange={handleFilterChange}
                    placeholder="e.g. Software Engineer"
                  />
                </div>
                
                <div className="filter-item">
                  <label>
                    <FontAwesomeIcon icon={faMapMarkerAlt} />
                    <span>Location</span>
                  </label>
                  <input
                    type="text"
                    name="location"
                    value={filters.location}
                    onChange={handleFilterChange}
                    placeholder="e.g. New York, NY"
                  />
                </div>
                
                <div className="filter-item">
                  <label>
                    <FontAwesomeIcon icon={faGraduationCap} />
                    <span>Education</span>
                  </label>
                  <input
                    type="text"
                    name="education"
                    value={filters.education}
                    onChange={handleFilterChange}
                    placeholder="e.g. Stanford University"
                  />
                </div>
              </div>
              
              <button 
                className="close-filters"
                onClick={() => setShowFilters(false)}
              >
                <FontAwesomeIcon icon={faTimes} />
              </button>
            </div>
          )}
        </div>
      </div>
      
      <div className="search-results-container">
        <h2>People ({searchResults.length})</h2>
        
        {searchResults.length === 0 ? (
          <div className="no-results">
            <FontAwesomeIcon icon={faSearch} className="no-results-icon" />
            <h3>No results found</h3>
            <p>Try adjusting your search or filters to find what you're looking for.</p>
          </div>
        ) : (
          <div className="user-cards">
            {searchResults.map(user => (
              <div className="user-card" key={user.id}>
                <div className="user-card-header">
                  <img src={user.profileImage} alt={user.name} className="user-avatar" />
                  <div className="user-info">
                    <h3>{user.name}</h3>
                    <p className="user-profession">{user.profession}</p>
                    <p className="user-location">
                      <FontAwesomeIcon icon={faMapMarkerAlt} />
                      <span>{user.location}</span>
                    </p>
                  </div>
                </div>
                
                <div className="user-details">
                  <p className="user-education">
                    <FontAwesomeIcon icon={faGraduationCap} />
                    <span>{user.education}</span>
                  </p>
                  
                  <div className="user-skills">
                    {user.skills.map((skill, index) => (
                      <span key={index} className="skill-tag">{skill}</span>
                    ))}
                  </div>
                  
                  <div className="user-connections">
                    <FontAwesomeIcon icon={faUser} />
                    <span>{user.connections} connections</span>
                  </div>
                </div>
                
                <div className="user-actions">
                  <button 
                    className="connect-button"
                    onClick={() => connectWithUser(user.id)}
                  >
                    Connect
                  </button>
                  <button className="view-profile-button">
                    View Profile
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Searching;
