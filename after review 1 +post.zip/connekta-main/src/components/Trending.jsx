import React, { useState, useRef, useEffect } from "react";
import { FaImage, FaVideo, FaSmile, FaMapMarkerAlt, FaPoll, FaEllipsisH, FaTimes, FaTimesCircle } from "react-icons/fa";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";
import "././../assets/css/Trending.css";

const PostingComponent = () => {
  const [postText, setPostText] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [showPostingInterface, setShowPostingInterface] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [username, setUsername] = useState("User");
  const [visibility, setVisibility] = useState("public");
  
  const fileInputRef = useRef(null);
  
  // Fetch user info when component mounts
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) return;
        
        const response = await axios.post('http://localhost:8080/users/getfullname', {
          csrid: token
        });
        
        if (response.data) {
          setUsername(response.data);
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    
    fetchUserData();
  }, []);
  
  // Convert file to base64
  const getBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!postText.trim() && !selectedImage) {
      setError("Please enter text or select an image for your post.");
      return;
    }
    
    setIsSubmitting(true);
    setError("");
    
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        setError("You need to be logged in to create a post.");
        setIsSubmitting(false);
        return;
      }
      
      let imageData = null;
      
      // If there's a selected image, convert it to base64
      if (selectedImage && selectedImage.file) {
        try {
          imageData = await getBase64(selectedImage.file);
          console.log("Image converted to base64 successfully");
        } catch (err) {
          console.error("Error converting image:", err);
          setError("Failed to process the image. Please try a different one.");
          setIsSubmitting(false);
          return;
        }
      }
      
      console.log("Submitting post with caption:", postText);
      console.log("Image data available:", imageData ? "Yes" : "No");
      
      const response = await axios.post('http://localhost:8080/api/posts/create', {
        csrid: token,
        caption: postText,
        imageUrl: imageData,
        visibility: visibility
      });
      
      console.log("Post creation response:", response.data);
      
      if (response.data.status === "success") {
        // Clear form
        setPostText("");
        setSelectedImage(null);
        setShowPostingInterface(false);
        setExpanded(false);
        alert("Post shared successfully!");
      } else {
        setError(response.data.message || "Failed to create post");
      }
    } catch (error) {
      console.error("Error creating post:", error);
      setError("An error occurred. Please try again later.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const expandTextarea = () => {
    setExpanded(true);
  };

  const showPostInterface = () => {
    setShowPostingInterface(true);
  };
  
  const handlePhotoClick = () => {
    fileInputRef.current.click();
  };
  
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Validate file type
      if (!file.type.match('image.*')) {
        setError("Please select an image file");
        return;
      }
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setError("Image size should be less than 5MB");
        return;
      }
      
      setSelectedImage({
        file,
        preview: URL.createObjectURL(file)
      });
      setExpanded(true);
      setError("");
    }
  };
  
  const removeImage = () => {
    if (selectedImage && selectedImage.preview) {
      URL.revokeObjectURL(selectedImage.preview);
    }
    setSelectedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="posting-wrapper">
      {!showPostingInterface && (
        <motion.div 
          className="fake-input-container"
          onClick={showPostInterface}
          whileHover={{ boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)" }}
        >
          <div className="fake-input-avatar">
            <img 
              src={`https://i.pravatar.cc/150?u=${username}`} 
              alt="User profile"
            />
          </div>
          <div className="fake-input">
            What's on your mind, {username.split(' ')[0]}?
          </div>
        </motion.div>
      )}

      <AnimatePresence>
        {showPostingInterface && (
          <motion.div 
            className="posting-container"
            initial={{ opacity: 0, y: -20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
          >
            <div className="posting-header">
              <motion.h3 
                whileHover={{ scale: 1.03 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                Share your thoughts
              </motion.h3>
              <motion.button 
                className="close-button"
                onClick={() => setShowPostingInterface(false)}
                whileHover={{ scale: 1.2, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
              >
                <FaTimes />
              </motion.button>
            </div>
            
            <div className="post-content">
              <div className="user-profile">
                <div className="avatar-wrapper">
                  <img 
                    src={`https://i.pravatar.cc/150?u=${username}`} 
                    alt="User profile"
                    className="user-avatar" 
                  />
                  <span className="status-indicator"></span>
                </div>
                <div className="post-context">
                  <span className="username">{username}</span>
                  <div className="privacy-selector" onClick={() => {
                    const nextVisibility = visibility === "public" ? "friends" : "public";
                    setVisibility(nextVisibility);
                  }}>
                    <span>{visibility === "public" ? "Public" : "Friends Only"}</span>
                    <svg viewBox="0 0 20 20" width="16" height="16">
                      <path d="M5 8l5 5 5-5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </div>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="input-wrapper" onClick={expandTextarea}>
                  <textarea 
                    className={`post-input ${expanded ? 'expanded' : ''}`}
                    placeholder={expanded ? "What would you like to share today?" : "What's on your mind?"}
                    value={postText}
                    onChange={(e) => setPostText(e.target.value)}
                    disabled={isSubmitting}
                    autoFocus
                  />
                </div>
                
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  style={{ display: 'none' }}
                  disabled={isSubmitting}
                />
                
                {selectedImage && (
                  <motion.div 
                    className="media-preview"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="image-preview-container">
                      <img 
                        src={selectedImage.preview}
                        alt="Selected preview"
                        className="image-preview"
                      />
                      <button
                        type="button"
                        className="remove-image-btn"
                        onClick={removeImage}
                        disabled={isSubmitting}
                      >
                        <FaTimesCircle />
                      </button>
                    </div>
                    <div className="image-name">
                      {selectedImage.file.name.length > 25 
                        ? selectedImage.file.name.substring(0, 22) + '...' 
                        : selectedImage.file.name}
                    </div>
                  </motion.div>
                )}
                
                {error && (
                  <div className="error-message" style={{color: "red", marginBottom: "10px"}}>
                    {error}
                  </div>
                )}
                
                <div className="post-options-container">
                  <div className="add-to-post">
                    <div className="options-label">Add to your post</div>
                    <div className="post-options">
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn photo"
                        onClick={handlePhotoClick}
                        disabled={isSubmitting}
                      >
                        <FaImage />
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn video"
                        disabled={true}
                      >
                        <FaVideo />
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn feeling"
                        disabled={true}
                      >
                        <FaSmile />
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn location"
                        disabled={true}
                      >
                        <FaMapMarkerAlt />
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn poll"
                        disabled={true}
                      >
                        <FaPoll />
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn more"
                        disabled={true}
                      >
                        <FaEllipsisH />
                      </motion.button>
                    </div>
                  </div>
                </div>
                
                <motion.button 
                  type="submit" 
                  className={`post-button ${(postText.length > 0 || selectedImage) ? 'active' : ''}`}
                  disabled={isSubmitting || (postText.length === 0 && !selectedImage)}
                  whileHover={{ scale: (postText.length > 0 || selectedImage) ? 1.02 : 1 }}
                  whileTap={{ scale: (postText.length > 0 || selectedImage) ? 0.98 : 1 }}
                >
                  {isSubmitting ? "Posting..." : "Share Now"}
                </motion.button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PostingComponent;
