import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../assets/css/Stories.css'; // We'll reuse the same CSS file with a few modifications

const FriendSuggestions = () => {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSuggestions = async () => {
      try {
        const token = localStorage.getItem('csrid');
        if (!token) {
          throw new Error('No authentication token found');
        }

        const response = await axios.post('http://localhost:8080/friends/suggestions', {
          csrid: token
        });

        if (response.data.status === 'success') {
          setSuggestions(response.data.suggestions || []);
        } else {
          throw new Error(response.data.message || 'Failed to fetch friend suggestions');
        }
      } catch (err) {
        console.error('Error fetching friend suggestions:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchSuggestions();
  }, []);

  const handleSendRequest = async (userId) => {
    try {
      const token = localStorage.getItem('csrid');
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await axios.post('http://localhost:8080/friends/send-request', {
        csrid: token,
        receiverId: userId
      });

      if (response.data.status === 'success') {
        // Update the state to mark request as sent
        setSuggestions(prevSuggestions => 
          prevSuggestions.map(suggestion => 
            suggestion.id === userId 
              ? { ...suggestion, requestSent: true } 
              : suggestion
          )
        );
      } else {
        throw new Error(response.data.message || 'Failed to send friend request');
      }
    } catch (err) {
      console.error('Error sending friend request:', err);
      alert('Failed to send friend request: ' + err.message);
    }
  };

  if (loading) {
    return <div className="stories-container">Loading friend suggestions...</div>;
  }

  if (error) {
    return <div className="stories-container">Error: {error}</div>;
  }

  return (
    <div className="stories-container">
      <div className="stories-header">
        <h3>Friend Suggestions</h3>
        <button className="see-all-btn">See All</button>
      </div>
      <div className="stories-list">
        {suggestions.length === 0 ? (
          <div className="no-suggestions">No suggestions found at the moment.</div>
        ) : (
          suggestions.map((suggestion) => (
            <div key={suggestion.id} className="suggestion-item story-item">
              <div className="story-avatar-container">
                <img src={suggestion.avatar} alt={suggestion.fullname} className="story-avatar" />
              </div>
              <div className="suggestion-info story-info">
                <p className="story-username">{suggestion.fullname}</p>
                <p className="story-timestamp">{suggestion.email}</p>
              </div>
              <button 
                className={`add-friend-btn ${suggestion.requestSent ? 'request-sent' : ''}`}
                onClick={() => !suggestion.requestSent && handleSendRequest(suggestion.id)}
                disabled={suggestion.requestSent}
              >
                {suggestion.requestSent ? 'Request Sent' : '+ Add Friend'}
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default FriendSuggestions;
