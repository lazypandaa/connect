import React from 'react';
import './../assets/css/Main.css';
import Post from './Post';

const MainContent = () => {
  return (
    <div className="main-content">
      <Post username="john_doe" image="https://source.unsplash.com/random" caption="Beautiful sunset!" />
    </div>
  );
};

export default MainContent;