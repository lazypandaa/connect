import React from 'react';
import '../assets/css/Stories.css';

const Stories = () => {
  // Mock data for stories based on the image you provided
  const stories = [
    {
      id: 1,
      username: 'Charishma Clg Avgr',
      time: '6h ago',
      avatar: 'https://randomuser.me/api/portraits/women/32.jpg',
      hasStory: true,
    },
    {
      id: 2,
      username: 'Mahathi Nandam Clg',
      time: '6h ago',
      avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
      hasStory: true,
    },
    {
      id: 3,
      username: 'Rishi Bokinala 😊 😉 Scl',
      time: '6h ago',
      avatar: 'https://randomuser.me/api/portraits/men/22.jpg',
      hasStory: true,
    },
    {
      id: 4,
      username: 'A. k. v. rao',
      time: '8h ago',
      avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
      hasStory: true,
    },
    {
      id: 5,
      username: 'Jayanth Anna Gym',
      time: '9h ago',
      avatar: 'https://randomuser.me/api/portraits/men/65.jpg', 
      hasStory: true,
    },
    {
      id: 6,
      username: 'Ravinder Reddy AIML 2.EVE',
      time: '10h ago',
      avatar: 'https://randomuser.me/api/portraits/men/77.jpg',
      hasStory: true,
    },
    {
      id: 7,
      username: 'Beswanth Bunny',
      time: '12h ago',
      avatar: 'https://randomuser.me/api/portraits/men/42.jpg',
      hasStory: true,
    },
    {
      id: 8,
      username: 'Livie',
      time: '13h ago',
      avatar: 'https://randomuser.me/api/portraits/women/28.jpg',
      hasStory: true,
    }
  ];

  return (
    <div className="stories-container">
      <div className="stories-header">
        <h3>Recent Stories</h3>
        <button className="see-all-btn">See All</button>
      </div>
      <div className="stories-list">
        {stories.map((story) => (
          <div key={story.id} className="story-item">
            <div className="story-avatar-container">
              <img src={story.avatar} alt={story.username} className="story-avatar" />
            </div>
            <div className="story-info">
              <p className="story-username">{story.username}</p>
              <p className="story-timestamp">{story.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Stories;
