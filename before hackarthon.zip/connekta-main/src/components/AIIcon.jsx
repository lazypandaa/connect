import React, { useState, useRef, useEffect } from "react";
import { FaRobot } from "react-icons/fa";
import { IoSend } from "react-icons/io5";
import { BsEmojiSmile } from "react-icons/bs";
import "./../assets/css/AIIcon.css";

function AIComponent() {
  const [prompt, setPrompt] = useState(""); 
  const [loading, setLoading] = useState(false);
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [messages, setMessages] = useState([]);
  const messagesEndRef = useRef(null);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const togglePopup = () => {
    setIsPopupVisible(!isPopupVisible);
    if (!isPopupVisible && messages.length === 0) {
      // Add welcome message when opening for the first time
      setMessages([
        {
          type: "ai",
          content: "Hi there! I'm Nexus, your AI assistant. How can I help you today?",
          time: getTimeString()
        }
      ]);
    }
  };

  const getTimeString = () => {
    const now = new Date();
    return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} ${now.getHours() >= 12 ? 'AM' : 'PM'}`;
  };

  const handleGenerateContent = async () => {
    if (prompt.trim() === "") return;
    
    const userMessage = {
      type: "user",
      content: prompt,
      time: getTimeString()
    };
    
    setMessages(prevMessages => [...prevMessages, userMessage]);
    setLoading(true);
    setPrompt("");

    try {
      const res = await fetch("http://localhost:3000/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: prompt }),
      });

      if (!res.ok) {
        throw new Error(`HTTP error! Status: ${res.status}`);
      }

      const data = await res.json();
      const aiResponse = data.response || "Sorry, I couldn't process that request.";
      
      setMessages(prevMessages => [
        ...prevMessages, 
        {
          type: "ai",
          content: aiResponse,
          time: getTimeString()
        }
      ]);
    } catch (error) {
      console.error("Error fetching AI response:", error);
      setMessages(prevMessages => [
        ...prevMessages, 
        {
          type: "ai",
          content: "Sorry, I encountered an error while processing your request.",
          time: getTimeString()
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleGenerateContent();
    }
  };

  return (
    <div className="ai-icon-container">
      {/* Robot Icon Button */}
      <button className="ai-icon-button" onClick={togglePopup}>
        <FaRobot size={24} color="#b46c19" />
      </button>

      {/* Popup Window */}
      {isPopupVisible && (
        <div className="ai-popup">
          {/* Chat Header */}
          <div className="ai-popup-header">
            <img 
              src="/profile-avatar.jpg" 
              alt="Eswar Krishna" 
              className="user-avatar" 
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = "https://via.placeholder.com/48";
              }}
            />
            <div className="user-info">
              <div className="ai-agent-name">Eswar Krishna</div>
              <div className="ai-agent-status">
                <span className="status-dot"></span>
                Active Now
              </div>
            </div>
          </div>

          {/* Chat Messages */}
          <div className="ai-popup-body">
            <div className="chat-messages">
              {messages.map((message, index) => (
                <div 
                  key={index} 
                  className={`message ${message.type === 'user' ? 'message-right' : 'message-left'}`}
                >
                  {message.content}
                  <span className="message-time">{message.time}</span>
                </div>
              ))}
              
              {loading && (
                <div className="loading-indicator">
                  <div className="typing-dot"></div>
                  <div className="typing-dot"></div>
                  <div className="typing-dot"></div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </div>

          {/* Chat Input */}
          <div className="chat-input-container">
            <input
              type="text"
              className="chat-input"
              placeholder="Type a message..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            <button className="emoji-button">
              <BsEmojiSmile size={18} />
            </button>
            <button 
              className="send-button"
              onClick={handleGenerateContent}
              disabled={loading || !prompt.trim()}
            >
              <IoSend size={18} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default AIComponent;