import React, { useState, useEffect } from "react";
import "./../assets/css/Profile.css";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faRupeeSign, faCrown, faChevronRight } from '@fortawesome/free-solid-svg-icons';

const Profile = () => {
  const [userName, setUserName] = useState('User');
  
  useEffect(() => {
    // Get the username from localStorage when component mounts
    const storedUserName = localStorage.getItem("userName");
    const storedUser = localStorage.getItem("user");
    
    if (storedUserName) {
      setUserName(storedUserName);
    } else if (storedUser) {
      // Try to get name from user object if it exists
      try {
        const userObj = JSON.parse(storedUser);
        if (userObj.fullname || userObj.name || userObj.username) {
          setUserName(userObj.fullname || userObj.name || userObj.username);
        }
      } catch (e) {
        console.error("Error parsing user data:", e);
      }
    }
  }, []);

  return (
    <div className="profile-card">
      {/* Profile Header */}
      <div className="profile-header">
        <div><img
          src="https://avatars.githubusercontent.com/u/77490521?v=4"
          alt="profile"
          className="w-20 h-20 rounded-full border-2 border-white shadow-md"
        /></div>
        
        <div className="profile-info mt-10">
          <h2 className="profile-name ">{userName}</h2>
          <p className="profile-location">Vijayawada, Andhra Pradesh</p>
        </div>
      </div>
      
      {/* Profile Details */}
      <div className="profile-details">
        <p className="profile-university">KL University, Vaddeswaram</p>
        
        <div className="profile-stats">
          <div className="stat-row">
            <span className="stat-label">Profile Viewers</span>
            <span className="stat-value">68</span>
          </div>
          <div className="stat-row">
            <span className="stat-label">Profile Rating</span>
            <span className="stat-value">4.5</span>
          </div>
        </div>
      </div>
      
      {/* Premium Section */}
      <div className="premium-container">
        <div className="premium-badge">
          <FontAwesomeIcon icon={faCrown} className="crown-icon" />
          <span>PREMIUM</span>
        </div>
        
        <h3 className="premium-title">Unlock Premium Features</h3>
        <p className="premium-description">Get access to advanced tools, analytics, and exclusive insights</p>
        
        <div className="premium-offer">
          <div className="premium-offer-content">
            <div className="premium-price-container">
              <span className="premium-label">Special Offer</span>
              <div className="premium-price">
                <FontAwesomeIcon icon={faRupeeSign} className="rupee-icon" />
                <span className="price-value">0</span>
              </div>
              <span className="premium-period">for 1 month</span>
            </div>
            
            <button className="premium-button">
              <span>Try Premium Free</span>
              <FontAwesomeIcon icon={faChevronRight} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;