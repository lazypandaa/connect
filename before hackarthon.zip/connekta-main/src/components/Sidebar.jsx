import React from "react";
import { FaBookmark, FaUsers, FaNewspaper } from "react-icons/fa";
import "./../assets/css/Sidebar.css";

const Sidebar = () => {
  const users = [
    { id: 1, name: "User 1" },
    { id: 2, name: "User 2" },
    { id: 3, name: "User 3" },
    { id: 4, name: "User 4" },
  ];

  return (
    <div className="sidebar">
      <div className="sidebar-menu">
        <div className="menu-item">
          <FaBookmark className="icon" />
          <span className="text-gray-400">Saved items</span>
        </div>
        <div className="menu-item">
          <FaUsers className="icon" />
          <span className="text-gray-400">Groups</span>
        </div>
        <div className="menu-item">
          <FaNewspaper className="icon" />
          <span className="text-gray-400">Newsletters</span>
        </div>
      </div>

      <div className="user-list">
        {users.map((user) => (
          <div key={user.id} className="user-avatar">
            <img
              src={`https://i.pravatar.cc/50?img=${user.id}`} // Placeholder avatar
              alt={user.name}
            />
            <span className="status-dot"></span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Sidebar;
