import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './../assets/css/PostActions.css'; // Add CSS for popup styling

const PostActions = () => {
  const [caption, setCaption] = useState('');
  const [imageFile, setImageFile] = useState(null);
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    const fetchUserId = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/auth/user"); // Replace with actual endpoint
        setUserId(response.data.userId);
        console.log("User ID fetched:", response.data.userId);
      } catch (error) {
        console.error("Error fetching user ID:", error.response);
      }
    };

    fetchUserId();
  }, []);

  const handleOpenPopup = () => {
    setIsPopupVisible(true);
  };

  const handleClosePopup = () => {
    setIsPopupVisible(false);
    setCaption('');
    setImageFile(null); // Reset fields
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("userId", userId); // Use fetched user ID
    formData.append("caption", caption);
    formData.append("media", imageFile);

    try {
      const response = await axios.post("http://localhost:8080/api/posts/create", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      alert("Post created successfully:", response.data);
      handleClosePopup(); // Close popup after successful submission
    } catch (error) {
      console.error("Error creating post:", error.response);
    }
  };

  return (
    <div>
      {isPopupVisible && (
        <div className="popup-overlay">
          <div className="popup">
            <h3>Create Post</h3>
            <form onSubmit={handleSubmit}>
              <div>
                <label>Caption</label>
                <input
                  type="text"
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  required
                />
              </div>
              <div>
                <label>Image</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setImageFile(e.target.files[0])}
                  required
                />
              </div>
              <div className="popup-actions">
                <button type="submit" className="popup-submit-button">Submit</button>
                <button type="button" onClick={handleClosePopup} className="popup-cancel-button">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PostActions;
