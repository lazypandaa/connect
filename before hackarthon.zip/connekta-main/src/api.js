export function callApi(reqmethod, url, data, responseHandler) {
    var option;

    if (reqmethod === 'GET' || reqmethod === 'DELETE') {
        option = { method: reqmethod, headers: { 'Content-Type': 'application/json' } };
    } else {
        option = { method: reqmethod, headers: { 'Content-Type': 'application/json' }, body: data };
    }

    // console.log("API Request:", { url, option }); // Log the API request details

    return fetch(url, option)
        .then(response => {
            if (!response.ok) {
                throw new Error(response.status + ' ' + response.statusText);
            }
            // Check if the response is JSON
            const contentType = response.headers.get("content-type");
            if (contentType && contentType.indexOf("application/json") !== -1) {
                return response.json(); // Parse JSON response
            } else {
                return response.text(); // Parse text response
            }
        })
        .then(data => responseHandler(data))
        .catch(error => {
            console.error("API Error:", error); // Log any errors
            alert(error);
        });
}

// export function setSession(sesname, sesvalue, expday)
// {
//     let D = new Date();
//     D.setTime(D.getTime() + expday * 86400000);
//     document.cookie = `${sesname}=${sesvalue};expires=${D.toUTCString()};path="/";secure`;    
// }

// export function getSession(sesname)
// {
//     let decodeCookie = decodeURIComponent(document.cookie);
//     let cookieData = decodeCookie.split(";");

//     for(let x in cookieData)
//     {
//         if(cookieData[x].includes(sesname))
//             return cookieData[x].substring(cookieData[x].indexOf(sesname) + sesname.length + 1);

//         return "";
//     }
//     console.log(sesname);
// }

export function setSession(sesname, sesvalue, expday) {
    let D = new Date();
    D.setTime(D.getTime() + expday * 86400000); // Set expiration time in milliseconds
    document.cookie = `${sesname}=${sesvalue};expires=${D.toUTCString()};path=/`; // Removed 'secure' for local testing
}

export function getSession(sesname) {
    const decodeCookie = decodeURIComponent(document.cookie); // Decode the cookie string
    const cookieData = decodeCookie.split(";"); // Split into key-value pairs

    for (let x of cookieData) {
        const [key, value] = x.trim().split("="); // Trim spaces and split key-value
        if (key === sesname) {
            return value; // Return the value if the key matches
        }
    }

    return ""; // Return an empty string if the session is not found
}