import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import Header from './components/Header';
import ProfilePage from './components/ProfilePage';
import MainContent from './components/Main';
import Trending from './components/Trending';
import PostAction from './components/PostActions';
import Feed from './components/Feed'; 
import Sidebar from './components/Sidebar';
import Profile from './components/Profile';
import LoginPage from './components/LoginPage'; 
import SignUpPage from './components/SignUpPage'; 
import ChatPage from './components/ChatPage'; 
import AIIcon from './components/AIIcon';
import Stories from './components/Stories'; // Import the Stories component
import Searching from './components/Searching'; // Import the Searching component

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  return (
    <Router>
      <div className="app">
        {isLoggedIn ? (
          <>
            <Header />
            <div className="content">
              <Routes>
                <Route path="/" element={
                  <>
                    <div className="sidebar1">
                      <Trending />
                      <Stories /> {/* Moved Stories component to left sidebar */}
                      <div className=''><PostAction /></div>
                      <div className=" flex justify-center items-center mt-10"><AIIcon /></div>
                    </div>
                    <div className="main-section">
                      {/* <div className='pl-4 '><PostAction /></div> */}
                      <div><PostAction /></div>
                      <div><Feed /></div>
                    </div>
                    <div className="trending1">
                      {/* <Trending /> */}
                      <Profile />
                      <Sidebar />
                    </div>
                  </>
                } />
                <Route path="/profilePage" element={<ProfilePage />} />
                <Route path="/chatpage" element={<ChatPage />} />
                <Route path="/search" element={<Searching />} />
              </Routes>
            </div>
          </>
        ) : (
          <Routes>
            <Route path="/" element={<LoginPage onLogin={handleLogin} />} />
            <Route path="/signup" element={<SignUpPage />} />
          </Routes>
        )}
      </div>
    </Router>
  );
};

export default App;