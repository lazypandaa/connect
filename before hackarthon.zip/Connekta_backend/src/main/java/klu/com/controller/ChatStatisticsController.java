package klu.com.controller;

import klu.com.model.JWTManager;
import klu.com.service.ChatStatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api")
public class ChatStatisticsController {
    
    @Autowired
    private ChatStatisticsService chatStatisticsService;
    
    @Autowired
    private JWTManager jwtManager;
    
    /**
     * Get summary statistics for a user's chats
     */
    @PostMapping("/chat-statistics")
    public Map<String, Object> getChatStatistics(@RequestBody Map<String, Object> request) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String token = (String) request.get("csrid");
        String email = jwtManager.validateToken(token);
        if ("401".equals(email)) {
            response.put("status", "error");
            response.put("message", "Invalid token");
            return response;
        }
        
        Long userId = Long.parseLong(request.get("userId").toString());
        
        return chatStatisticsService.getChatStatistics(userId);
    }
    
    /**
     * Get unread message counts for a user
     */
    @PostMapping("/unread-counts")
    public Map<String, Object> getUnreadCounts(@RequestBody Map<String, Object> request) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String token = (String) request.get("csrid");
        String email = jwtManager.validateToken(token);
        if ("401".equals(email)) {
            response.put("status", "error");
            response.put("message", "Invalid token");
            return response;
        }
        
        Long userId = Long.parseLong(request.get("userId").toString());
        
        return chatStatisticsService.getUnreadMessageCounts(userId);
    }
    
    /**
     * Get last messages for each chat conversation
     */
    @PostMapping("/last-messages")
    public Map<String, Object> getLastMessages(@RequestBody Map<String, Object> request) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate token
        String token = (String) request.get("csrid");
        String email = jwtManager.validateToken(token);
        if ("401".equals(email)) {
            response.put("status", "error");
            response.put("message", "Invalid token");
            return response;
        }
        
        Long userId = Long.parseLong(request.get("userId").toString());
        
        return chatStatisticsService.getLastMessages(userId);
    }
}
