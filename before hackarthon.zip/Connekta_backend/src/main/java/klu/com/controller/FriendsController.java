package klu.com.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import klu.com.model.FriendsManager;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/friends")
public class FriendsController {
    
    @Autowired
    private FriendsManager friendsManager;
    
    /**
     * Send a friend request to another user
     */
    @PostMapping("/send-request")
    public Map<String, Object> sendFriendRequest(@RequestBody Map<String, Object> request) {
        String token = (String) request.get("csrid");
        Long receiverId = Long.valueOf(request.get("receiverId").toString());
        return friendsManager.sendFriendRequest(token, receiverId);
    }
    
    /**
     * Accept a friend request
     */
    @PostMapping("/accept-request")
    public Map<String, Object> acceptFriendRequest(@RequestBody Map<String, Object> request) {
        String token = (String) request.get("csrid");
        Long requestId = Long.valueOf(request.get("requestId").toString());
        return friendsManager.acceptFriendRequest(token, requestId);
    }
    
    /**
     * Reject a friend request
     */
    @PostMapping("/reject-request")
    public Map<String, Object> rejectFriendRequest(@RequestBody Map<String, Object> request) {
        String token = (String) request.get("csrid");
        Long requestId = Long.valueOf(request.get("requestId").toString());
        return friendsManager.rejectFriendRequest(token, requestId);
    }
    
    /**
     * Remove a friend
     */
    @PostMapping("/remove-friend")
    public Map<String, Object> removeFriend(@RequestBody Map<String, Object> request) {
        String token = (String) request.get("csrid");
        Long friendId = Long.valueOf(request.get("friendId").toString());
        return friendsManager.removeFriend(token, friendId);
    }
    
    /**
     * Block a user
     */
    @PostMapping("/block-user")
    public Map<String, Object> blockUser(@RequestBody Map<String, Object> request) {
        String token = (String) request.get("csrid");
        Long userId = Long.valueOf(request.get("userId").toString());
        return friendsManager.blockUser(token, userId);
    }
    
    /**
     * Unblock a user
     */
    @PostMapping("/unblock-user")
    public Map<String, Object> unblockUser(@RequestBody Map<String, Object> request) {
        String token = (String) request.get("csrid");
        Long userId = Long.valueOf(request.get("userId").toString());
        return friendsManager.unblockUser(token, userId);
    }
    
    /**
     * Get all friends of the current user
     */
    @PostMapping("/get-friends")
    public Map<String, Object> getFriends(@RequestBody Map<String, String> request) {
        String token = request.get("csrid");
        return friendsManager.getFriends(token);
    }
    
    /**
     * Get all pending friend requests for the current user
     */
    @PostMapping("/pending-requests")
    public Map<String, Object> getPendingRequests(@RequestBody Map<String, String> request) {
        String token = request.get("csrid");
        return friendsManager.getPendingRequests(token);
    }
    
    /**
     * Get all friend requests sent by the current user
     */
    @PostMapping("/sent-requests")
    public Map<String, Object> getSentRequests(@RequestBody Map<String, String> request) {
        String token = request.get("csrid");
        return friendsManager.getSentRequests(token);
    }
    
    /**
     * Search for users to add as friends
     */
    @PostMapping("/search-users")
    public Map<String, Object> searchUsers(@RequestBody Map<String, String> request) {
        String token = request.get("csrid");
        String query = request.get("query");
        return friendsManager.searchUsers(token, query);
    }
}
