package klu.com.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import klu.com.repository.UsersRepository;
import java.util.Optional;

@Service
public class UsersManager {

    @Autowired
    private UsersRepository usersRepo;

    @Autowired
    JWTManager JM;

    public String addUser(Users user) {
        usersRepo.save(user);
        return "User Added Successfully";
    }

    public String login(String email, String password) {
        if (usersRepo.validateCredentials(email, password) > 0) {
            String token = JM.generateToken(email);
            return token;
        } else {
            return "401::Invalid Credentials";
        }
    }

    public String getFullname(String token) {
        String email = JM.validateToken(token);
        if (email.compareTo("401") == 0) {
            return "401::Token Expired";
        }
        Users U = usersRepo.findByEmail(email).get();
        return U.getFullname();
    }

    public String getUserId(String token) {
        String email = JM.validateToken(token);
        if (email.compareTo("401") == 0) {
            return "401::Token Expired";
        }
        
        Users U = usersRepo.findByEmail(email).orElse(null);
        if (U == null) return "404::User Not Found";
        return String.valueOf(U.getId());
    }
}
