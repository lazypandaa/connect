// Import necessary modules
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { verifyToken } = require('../middleware/auth');

// Add this new route to get posts directly from the database
router.post('/get', verifyToken, async (req, res) => {
  try {
    const { user_id } = req.body;
    
    if (!user_id) {
      return res.status(400).json({ status: 'error', message: 'User ID is required' });
    }
    
    // Query the posts table directly
    const [posts] = await db.query(
      'SELECT * FROM posts WHERE user_id = ? ORDER BY created_at DESC',
      [user_id]
    );
    
    console.log(`Found ${posts.length} posts for user ${user_id}`);
    
    // Return the posts
    res.json(posts);
  } catch (error) {
    console.error("Error fetching posts:", error);
    res.status(500).json({ status: 'error', message: 'Failed to fetch posts' });
  }
});

module.exports = router;