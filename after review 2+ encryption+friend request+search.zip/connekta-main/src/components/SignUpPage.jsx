import React, { useState } from 'react';
import './../assets/css/LoginPage.css';
import leftImage from './../assets/images/connekta+IconLogoTagline.png';
import connecta from './../assets/images/connekta logo.png';
import { callApi } from '../api';

const SignupPage = ({ onSignUpSuccess }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setError('');
    
    // Form validation
    if (!formData.fullName.trim() || !formData.email.trim() || !formData.password) {
      setError('All fields are required');
      return;
    }
    
    // Check if passwords match
    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match!");
      return;
    }
    
    // Password strength validation
    if (formData.password.length < 8) {
      setError("Password must be at least 8 characters long");
      return;
    }

    setLoading(true);

    const data = JSON.stringify({
      fullname: formData.fullName,
      email: formData.email,
      password: formData.password,
      // The password will be encrypted on the server side
    });

    try {
      await callApi("POST", "http://localhost:8080/users/signup", data, getResponse);
    } catch (error) {
      console.error("Error during signup:", error);
      setError('An error occurred during signup. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const getResponse = (res) => {
    if (res.includes("Successfully")) {
      // Success response
      alert("Signup successful! Please log in.");
      
      // Clear form
      setFormData({
        fullName: '',
        email: '',
        password: '',
        confirmPassword: ''
      });
      
      if (onSignUpSuccess) {
        onSignUpSuccess();
      }
    } else {
      // Error response
      setError(res || "Signup failed. Please try again.");
    }
  };

  return (
    <div className="login-page">
      <div className="left-bar">
        <img src={leftImage} alt="Connekta" />
      </div>

      <div className="login-container">
        <div className="flex justify-center items-center">
          <img className="w-10 h-10" src={connecta} alt="Connekta" />
        </div>

        {error && <div className="error-message text-red-500 mb-4">{error}</div>}

        <input
          type="text"
          name="fullName"
          placeholder="Full Name"
          value={formData.fullName}
          onChange={handleChange}
          id="fullname"
          required
        />
        <input
          type="email"
          name="email"
          placeholder="E-Mail"
          value={formData.email}
          onChange={handleChange}
          id="email"
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          id="passwordsignup"
          required
        />
        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirm Password"
          value={formData.confirmPassword}
          onChange={handleChange}
          id="passwordsignup_confirm"
          required
        />
        <div className="button-group">
          <button 
            className="signup-button" 
            onClick={handleSignup}
            disabled={loading}
          >
            {loading ? "Signing Up..." : "Sign Up"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SignupPage;
