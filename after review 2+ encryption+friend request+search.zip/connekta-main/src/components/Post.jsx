import React, { useState, useContext } from 'react';
import './../assets/css/Post.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faThumbsUp, faComment, faShare } from '@fortawesome/free-solid-svg-icons';
import { ThemeContext } from '../context/ThemeContext';

const Post = ({ username, image, caption, avatar, initialLikes, initialComments, initialShares }) => {
  const { theme } = useContext(ThemeContext);
  const [likes, setLikes] = useState(initialLikes);
  const [comments, setComments] = useState(initialComments);
  const [shares, setShares] = useState(initialShares);
  const [isExpanded, setIsExpanded] = useState(false);

  const handleLike = (e) => {
    e.stopPropagation();
    setLikes(likes + 1);
  };

  const handleComment = (e) => {
    e.stopPropagation();
    setComments(comments + 1);
  };

  const handleShare = (e) => {
    e.stopPropagation();
    setShares(shares + 1);
  };

  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div className={`post ${isExpanded ? 'expanded' : ''} ${theme}`} onClick={toggleExpand}>
      <div className='flex flex-row items-center'>
        <img src={avatar} alt="User" className='w-10 h-10 rounded-full' />
        <h3 className='ml-2'>{username}</h3>
      </div>
      <img src={image} alt="Post" />
      <p>{caption}</p>
      <div className='flex flex-row gap-5 mt-2'>
        <div className='flex items-center' onClick={handleLike}>
          <FontAwesomeIcon icon={faThumbsUp} className='mr-1' />
          <span>{likes}</span>
        </div>
        <div className='flex items-center' onClick={handleComment}>
          <FontAwesomeIcon icon={faComment} className='mr-1' />
          <span>{comments}</span>
        </div>
        <div className='flex items-center' onClick={handleShare}>
          <FontAwesomeIcon icon={faShare} className='mr-1' />
          <span>{shares}</span>
        </div>
      </div>
    </div>
  );
};

export default Post;