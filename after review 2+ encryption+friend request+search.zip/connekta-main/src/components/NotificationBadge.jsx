import React, { useState, useEffect } from 'react';
import { FaBell } from 'react-icons/fa';
import axios from 'axios';
import { Link } from 'react-router-dom';

const NotificationBadge = () => {
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    const fetchNotificationCount = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) return;

        // First, get pending friend requests count
        const friendRequestsResponse = await axios.post(
          'http://localhost:8080/friends/pending-requests',
          { csrid: token }
        );
        
        let count = 0;
        
        if (friendRequestsResponse.data.status === 'success') {
          count += friendRequestsResponse.data.requests?.length || 0;
        }
        
        // You can add more notification types here
        
        setUnreadCount(count);
      } catch (error) {
        console.error("Error fetching notification count:", error);
      }
    };

    fetchNotificationCount();
    
    // Poll for new notifications every minute
    const interval = setInterval(fetchNotificationCount, 60000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <Link to="/notifications" className="relative">
      <FaBell className="text-xl text-gray-700" />
      {unreadCount > 0 && (
        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
          {unreadCount > 9 ? '9+' : unreadCount}
        </span>
      )}
    </Link>
  );
};

export default NotificationBadge;
