import React, { useState, useEffect, useRef } from "react";
import "./../assets/css/ChatPage.css";
import { FaPaperPlane, FaSearch, FaEllipsisV, FaPhone, FaVideo, FaSmile, FaPaperclip } from "react-icons/fa";
import { IoMdInformationCircleOutline } from "react-icons/io";
import { BsThreeDotsVertical } from "react-icons/bs";
import axios from "axios";

const ChatPage = () => {
  const [userName, setUserName] = useState('User');
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [activeChat, setActiveChat] = useState(null);
  const [activeMediaTab, setActiveMediaTab] = useState("Photos");
  const [friends, setFriends] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentUserId, setCurrentUserId] = useState(null);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const messagesEndRef = useRef(null);
  const [messagePollingInterval, setMessagePollingInterval] = useState(null);

  // Function to scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Get current user information
  useEffect(() => {
    const fetchUserInfo = async () => {
      const storedUserName = localStorage.getItem("userName");
      const storedUser = localStorage.getItem("user");
      
      try {
        let userId = null;
        
        if (storedUser) {
          const userObj = JSON.parse(storedUser);
          if (userObj.id) {
            userId = userObj.id;
            setCurrentUserId(userId);
          }
          
          if (userObj.fullname || userObj.name || userObj.username) {
            setUserName(userObj.fullname || userObj.name || userObj.username);
          }
        } else if (storedUserName) {
          setUserName(storedUserName);
          
          // Try to get user id from API if needed
          const token = localStorage.getItem('token');
          if (token) {
            try {
              const userResponse = await axios.post(
                'http://localhost:8080/api/user-profile',
                { csrid: token }
              );
              
              if (userResponse.data && userResponse.data.id) {
                userId = userResponse.data.id;
                setCurrentUserId(userId);
              }
            } catch (error) {
              console.error("Error fetching user profile:", error);
            }
          }
        }
      } catch (e) {
        console.error("Error parsing user data:", e);
      }
    };

    fetchUserInfo();
    fetchFriends();
  }, []);

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Setup message polling when active chat changes
  useEffect(() => {
    if (activeChat && currentUserId) {
      fetchChatMessages(currentUserId, activeChat);
      
      // Clear any existing polling
      if (messagePollingInterval) {
        clearInterval(messagePollingInterval);
      }
      
      // Set up polling for new messages every 5 seconds
      const interval = setInterval(() => {
        fetchChatMessages(currentUserId, activeChat);
      }, 5000);
      
      setMessagePollingInterval(interval);
    }
    
    // Clean up interval when component unmounts or active chat changes
    return () => {
      if (messagePollingInterval) {
        clearInterval(messagePollingInterval);
      }
    };
  }, [activeChat, currentUserId]);

  const fetchFriends = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      
      if (!token) {
        setError("Please log in to view your friends");
        setLoading(false);
        return;
      }

      const response = await axios.post(
        'http://localhost:8080/friends/get-friends',
        { csrid: token }
      );
      
      if (response.data.status === 'success') {
        // Convert friends data to chat contacts format
        const friendsAsChatContacts = response.data.friends.map((friend, index) => ({
          id: friend.id,
          name: friend.fullname,
          status: Math.random() > 0.5 ? "online" : "offline", // Random online status for now
          lastMessage: "Click to start chatting",
          time: "Now",
          img: (index + 1).toString()
        }));
        
        setFriends(friendsAsChatContacts);
        
        // If we have friends, set the first one as active chat
        if (friendsAsChatContacts.length > 0 && !activeChat) {
          setActiveChat(friendsAsChatContacts[0].id);
        }
      } else {
        setError(response.data.message || "Failed to load friends");
      }
      
      setLoading(false);
    } catch (err) {
      console.error("Error fetching friends:", err);
      setError("Failed to load friends data");
      setLoading(false);
    }
  };

  const fetchChatMessages = async (currentUserId, friendId) => {
    try {
      setLoadingMessages(true);
      const token = localStorage.getItem('token');
      
      if (!token) {
        console.error("No token found");
        setLoadingMessages(false);
        return;
      }

      console.log(`Fetching messages between user ${currentUserId} and friend ${friendId}`);

      // Call the API to get chat messages between current user and friend
      const response = await axios.post(
        'http://localhost:8080/api/chat/messages',
        { 
          csrid: token,
          userId: currentUserId,
          friendId: friendId
        }
      );
      
      if (response.data) {
        // Format messages for display
        const formattedMessages = response.data.map(msg => {
          const timestamp = new Date(msg.timestamp);
          const formattedTime = timestamp.toLocaleTimeString('en-US', { 
            hour: 'numeric', 
            minute: '2-digit', 
            hour12: true 
          });
          
          // Determine if the message was sent by the current user or received
          const type = msg.senderId === currentUserId ? "sent" : "received";
          
          return {
            id: msg.id,
            text: msg.messageText,
            type: type,
            time: formattedTime,
            timestamp: timestamp,
            read_status: msg.readStatus
          };
        });
        
        // Sort messages by timestamp
        formattedMessages.sort((a, b) => a.timestamp - b.timestamp);
        
        setMessages(formattedMessages);
        setLoadingMessages(false);
      } else {
        // If no messages, set empty array
        setMessages([]);
        setLoadingMessages(false);
      }
    } catch (err) {
      console.error("Error fetching messages:", err);
      setMessages([]);
      setLoadingMessages(false);
    }
  };

  const handleSendMessage = async () => {
    if (newMessage.trim() !== "" && activeChat && currentUserId) {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          console.error("No token found");
          return;
        }
        
        // Current timestamp
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { 
          hour: 'numeric', 
          minute: '2-digit', 
          hour12: true 
        });
        
        // Add message to UI immediately (optimistic update)
        const tempMessage = {
          text: newMessage,
          type: "sent",
          time: timeString,
          timestamp: now,
          sending: true
        };
        
        setMessages(prevMessages => [...prevMessages, tempMessage]);
        setNewMessage("");
        
        // Send message to API
        const response = await axios.post(
          'http://localhost:8080/api/chat/send',
          {
            csrid: token,
            messageText: newMessage,
            senderId: currentUserId,
            receiverId: activeChat
          }
        );
        
        if (response.data && response.data.status === 'success') {
          // Replace temp message with confirmed message
          const confirmedMessage = {
            id: response.data.messageId,
            text: newMessage,
            type: "sent",
            time: timeString,
            timestamp: now,
            read_status: 0
          };
          
          setMessages(prevMessages => 
            prevMessages.map(msg => 
              msg === tempMessage ? confirmedMessage : msg
            )
          );
          
          // Update the last message for the contact in the sidebar
          updateLastMessage(activeChat, newMessage, timeString);
          
        } else {
          throw new Error(response.data?.message || "Failed to send message");
        }
      } catch (error) {
        console.error("Error sending message:", error);
        // Show error state on the failed message
        setMessages(prevMessages => 
          prevMessages.map(msg => 
            msg.sending ? {...msg, error: true} : msg
          )
        );
      }
    }
  };

  // Update the last message displayed in chat sidebar
  const updateLastMessage = (contactId, message, time) => {
    setFriends(prevFriends => 
      prevFriends.map(friend => 
        friend.id === contactId 
          ? { ...friend, lastMessage: message, time: time }
          : friend
      )
    );
  };

  // Handle user selecting a chat contact
  const handleChatSelect = (contactId) => {
    if (contactId !== activeChat) {
      setActiveChat(contactId);
      setMessages([]); // Clear current messages while loading
      setLoadingMessages(true);
    }
  };

  // Filter contacts based on search query
  const filteredContacts = friends.filter(contact => 
    contact.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const mediaItems = [
    { type: "photo", src: "https://source.unsplash.com/random/300x300?sig=1" },
    { type: "photo", src: "https://source.unsplash.com/random/300x300?sig=2" },
    { type: "photo", src: "https://source.unsplash.com/random/300x300?sig=3" },
  ];

  // Group messages by date for display with date separators
  const messagesByDate = messages.reduce((groups, message) => {
    const date = new Date(message.timestamp);
    const dateString = date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric'
    });
    
    if (!groups[dateString]) {
      groups[dateString] = [];
    }
    
    groups[dateString].push(message);
    return groups;
  }, {});

  // Get current active contact
  const activeContact = friends.find(contact => contact.id === activeChat) || (friends[0] || {});

  return (
    <div className="chat-container">
      <div className="chat-content">
        <aside className="chat-sidebar">
          <div className="sidebar-header">
            <h3>Messages</h3>
            <button className="action-button" onClick={fetchFriends} title="Refresh friends">
              <BsThreeDotsVertical />
            </button>
          </div>
          <div className="search-container">
            <input 
              type="text" 
              placeholder="Search friends..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="chat-list">
            {loading ? (
              <div className="flex justify-center items-center p-4 text-gray-500">Loading friends...</div>
            ) : error ? (
              <div className="flex justify-center items-center p-4 text-red-500">{error}</div>
            ) : filteredContacts.length === 0 ? (
              <div className="flex justify-center items-center p-4 text-gray-500">
                {searchQuery ? "No friends match your search" : "No friends yet"}
              </div>
            ) : (
              filteredContacts.map((contact) => (
                <div 
                  key={contact.id} 
                  className={`chat-item ${activeChat === contact.id ? 'active' : ''}`}
                  onClick={() => handleChatSelect(contact.id)}
                >
                  <img
                    src={`https://i.pravatar.cc/150?u=${contact.id}`}
                    alt={contact.name}
                  />
                  <div>
                    <strong>{contact.name}</strong>
                    <p>{contact.lastMessage}</p>
                  </div>
                  <span className="time">{contact.time}</span>
                  <span className={`status-indicator ${contact.status}`}></span>
                </div>
              ))
            )}
          </div>
        </aside>
        
        <main className="chat-main">
          <div className="chat-header">
            <img
              src={`https://i.pravatar.cc/150?u=${activeContact.id}`}
              alt={activeContact.name}
            />
            <div>
              <strong>{activeContact.name}</strong>
              <p className="status">{activeContact.status === 'online' ? 'Active Now' : 'Offline'}</p>
            </div>
            <div className="actions">
              <button className="action-button">
                <FaPhone />
              </button>
              <button className="action-button">
                <FaVideo />
              </button>
              <button className="action-button">
                <IoMdInformationCircleOutline />
              </button>
            </div>
          </div>
          
          <div className="chat-messages">
            {loadingMessages ? (
              <div className="flex justify-center items-center h-full text-gray-500">Loading messages...</div>
            ) : messages.length === 0 ? (
              <div className="flex justify-center items-center h-full flex-col text-gray-500">
                <div className="mb-4 text-3xl">👋</div>
                <div>No messages yet</div>
                <div className="mt-2 text-sm">Start the conversation with {activeContact.name}</div>
              </div>
            ) : (
              Object.entries(messagesByDate).map(([dateString, dateMessages]) => (
                <React.Fragment key={dateString}>
                  <div className="date-separator">
                    <span>{dateString}</span>
                  </div>
                  
                  {dateMessages.map((message, messageIndex) => (
                    <div 
                      key={message.id || messageIndex}
                      className={`message ${message.type} ${message.sending ? 'sending' : ''} ${message.error ? 'error' : ''}`}
                    >
                      {message.text}
                      {message.error && <div className="message-error-icon">!</div>}
                      <div className="message-time">
                        {message.time}
                      </div>
                    </div>
                  ))}
                </React.Fragment>
              ))
            )}
            <div ref={messagesEndRef} /> {/* Empty div for auto-scroll */}
          </div>
          
          <div className="chat-input">
            <button className="attachment-button">
              <FaPaperclip />
            </button>
            <div className="chat-input-wrapper">
              <input
                type="text"
                placeholder="Type a message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter") {
                    handleSendMessage();
                  }
                }}
              />
              <button className="attachment-button">
                <FaSmile />
              </button>
            </div>
            <button onClick={handleSendMessage} disabled={!newMessage.trim()}>
              <FaPaperPlane />
            </button>
          </div>
        </main>
        
        <aside className="chat-profile">
          <div className="profile-header">
            <img 
              src={`https://i.pravatar.cc/200?u=${activeContact.id}`}
              alt={activeContact.name}
              className="profile-avatar"
            />
            <h3 className="profile-name">{activeContact.name}</h3>
            <p className={`profile-status ${activeContact.status}`}>
              {activeContact.status === 'online' ? 'Online' : 'Offline'}
            </p>
            
            <div className="profile-actions">
              <button className="profile-action-button">
                <FaPhone />
              </button>
              <button className="profile-action-button">
                <FaVideo />
              </button>
              <button className="profile-action-button">
                <FaEllipsisV />
              </button>
            </div>
          </div>
          
          <div className="profile-info">
            <div className="info-item">
              <span className="info-label">Email:</span>
              <span className="info-value">{activeContact.name?.toLowerCase().replace(' ', '.')}@example.com</span>
            </div>
            <div className="info-item">
              <span className="info-label">Phone:</span>
              <span className="info-value">+1 (555) 123-4567</span>
            </div>
            <div className="info-item">
              <span className="info-label">Location:</span>
              <span className="info-value">New York, USA</span>
            </div>
          </div>
          
          <div className="shared-media">
            <h3>
              Shared Media
              <button className="profile-action-button">
                <FaEllipsisV />
              </button>
            </h3>
            
            <div className="media-tabs">
              <div 
                className={`media-tab ${activeMediaTab === 'Photos' ? 'active' : ''}`}
                onClick={() => setActiveMediaTab('Photos')}
              >
                Photos
              </div>
              <div 
                className={`media-tab ${activeMediaTab === 'Files' ? 'active' : ''}`}
                onClick={() => setActiveMediaTab('Files')}
              >
                Files
              </div>
              <div 
                className={`media-tab ${activeMediaTab === 'Links' ? 'active' : ''}`}
                onClick={() => setActiveMediaTab('Links')}
              >
                Links
              </div>
            </div>
            
            <div className="media-grid">
              {mediaItems.map((item, index) => (
                <div key={index} className="media-item">
                  <img src={item.src} alt={`Shared media ${index + 1}`} />
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default ChatPage;