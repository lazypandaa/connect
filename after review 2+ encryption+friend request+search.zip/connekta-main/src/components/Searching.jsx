import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faFilter, faUser, faBriefcase, faMapMarkerAlt, faGraduationCap, faTimes, faUserPlus } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../assets/css/Searching.css';

const Searching = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [filters, setFilters] = useState({
    profession: '',
    location: '',
    education: ''
  });
  const [showFilters, setShowFilters] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentUserId, setCurrentUserId] = useState(null);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [friends, setFriends] = useState([]);

  const navigate = useNavigate();

  // Fetch all users when component mounts
  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      setError(null);
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          setError("Please log in to search for users");
          setLoading(false);
          return;
        }

        // Get current user ID
        const userIdResponse = await axios.post(
          'http://localhost:8080/users/getuserid',
          { csrid: token }
        );

        if (userIdResponse.data) {
          setCurrentUserId(parseInt(userIdResponse.data));
        }

        // Get all users
        const response = await axios.get('http://localhost:8080/users/all');
        
        if (response.data && Array.isArray(response.data)) {
          // Filter out the current user
          const filteredUsers = response.data.filter(user => 
            user.user_id !== parseInt(userIdResponse.data)
          );
          setAllUsers(filteredUsers);
          setSearchResults(filteredUsers);
        } else {
          setError("Failed to fetch users");
        }

        // Fetch pending friend requests
        const pendingResponse = await axios.post(
          'http://localhost:8080/friends/sent-requests',
          { csrid: token }
        );

        if (pendingResponse.data.status === 'success') {
          // Extract the receiver IDs from the requests
          const pendingReceiverIds = pendingResponse.data.requests.map(
            request => request.receiver.id
          );
          setPendingRequests(pendingReceiverIds);
        }

        // Fetch existing friends
        const friendsResponse = await axios.post(
          'http://localhost:8080/friends/get-friends',
          { csrid: token }
        );

        if (friendsResponse.data.status === 'success') {
          // Extract friend IDs
          const friendIds = friendsResponse.data.friends.map(friend => friend.id);
          setFriends(friendIds);
        }

        setLoading(false);
      } catch (err) {
        console.error("Error fetching users:", err);
        setError("Failed to load users. Please try again later.");
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  // Handle search input changes
  const handleSearchChange = (e) => {
    const term = e.target.value;
    setSearchTerm(term);
    
    if (!term.trim()) {
      setSearchResults(allUsers);
      return;
    }
    
    // Filter users based on search term
    const filtered = allUsers.filter(user => 
      (user.fullname && user.fullname.toLowerCase().includes(term.toLowerCase())) ||
      (user.email && user.email.toLowerCase().includes(term.toLowerCase()))
    );
    
    setSearchResults(filtered);
  };

  // Handle filter changes
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({
      ...filters,
      [name]: value
    });
    
    // Apply filters
    applyFilters(searchTerm, { ...filters, [name]: value });
  };

  // Apply filters to search results
  const applyFilters = (term, currentFilters) => {
    let results = allUsers;
    
    // Apply search term filter
    if (term) {
      results = results.filter(user => 
        (user.fullname && user.fullname.toLowerCase().includes(term.toLowerCase())) ||
        (user.email && user.email.toLowerCase().includes(term.toLowerCase()))
      );
    }
    
    // Apply other filters (these are examples - adjust based on your actual data structure)
    if (currentFilters.profession && results[0]?.profession) {
      results = results.filter(user => 
        user.profession?.toLowerCase().includes(currentFilters.profession.toLowerCase())
      );
    }
    
    if (currentFilters.location && results[0]?.location) {
      results = results.filter(user => 
        user.location?.toLowerCase().includes(currentFilters.location.toLowerCase())
      );
    }
    
    if (currentFilters.education && results[0]?.education) {
      results = results.filter(user => 
        user.education?.toLowerCase().includes(currentFilters.education.toLowerCase())
      );
    }
    
    setSearchResults(results);
  };

  // Clear all filters
  const clearFilters = () => {
    setFilters({
      profession: '',
      location: '',
      education: ''
    });
    
    // Reset to original search results based only on search term
    if (searchTerm) {
      const filtered = allUsers.filter(user => 
        (user.fullname && user.fullname.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (user.email && user.email.toLowerCase().includes(searchTerm.toLowerCase()))
      );
      setSearchResults(filtered);
    } else {
      setSearchResults(allUsers);
    }
  };

  // Send friend request
  const sendFriendRequest = async (userId) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        alert("Please log in to send friend requests");
        return;
      }

      console.log("Searching: Sending friend request to user ID:", userId);
      console.log("Using token:", token.substring(0, 15) + "...");

      // Create axios instance with timeout
      const axiosInstance = axios.create({
        timeout: 10000 // 10 seconds
      });

      const response = await axiosInstance.post(
        'http://localhost:8080/friends/send-request',
        { 
          csrid: token,
          receiverId: userId 
        }
      );
      
      console.log("Friend request response:", response.data);
      
      if (response.data.status === 'success') {
        // Add to pending requests
        setPendingRequests([...pendingRequests, userId]);
        alert("Friend request sent successfully!");
      } else {
        alert(response.data.message || "Failed to send friend request");
      }
    } catch (err) {
      console.error("Error sending friend request:", err);
      
      // More detailed error logging
      if (err.response) {
        console.error("Response data:", err.response.data);
        console.error("Response status:", err.response.status);
      } else if (err.request) {
        console.error("Request was made but no response received");
        console.error("Request:", err.request);
      } else {
        console.error("Error message:", err.message);
      }
      
      // Suggest specific solutions based on error
      if (err.code === 'ECONNABORTED') {
        alert('Request timed out. Please check your connection and try again.');
      } else if (err.response && err.response.status === 401) {
        alert('Your session has expired. Please log in again.');
        // Optionally redirect to login
      } else {
        alert('Failed to send friend request. Please refresh the page and try again.');
      }
    }
  };

  // View user profile
  const viewProfile = (userId) => {
    navigate(`/profile/${userId}`);
  };

  // Get connection status button for a user
  const getConnectionButton = (userId) => {
    // If already friends
    if (friends.includes(userId)) {
      return (
        <button className="friends-button" disabled>
          <FontAwesomeIcon icon={faUser} /> Friends
        </button>
      );
    }
    
    // If request pending
    if (pendingRequests.includes(userId)) {
      return (
        <button className="pending-button" disabled>
          <FontAwesomeIcon icon={faUserPlus} /> Request Sent
        </button>
      );
    }
    
    // Otherwise, allow to connect
    return (
      <button 
        className="connect-button"
        onClick={() => sendFriendRequest(userId)}
      >
        <FontAwesomeIcon icon={faUserPlus} /> Connect
      </button>
    );
  };

  return (
    <div className="search-page">
      <div className="search-container">
        <div className="search-header">
          <h1>Find People & Make Connections</h1>
          <p>Connect with other users of Connekta</p>
        </div>
        
        <div className="search-bar-container">
          <div className="search-bar">
            <FontAwesomeIcon icon={faSearch} className="search-icon" />
            <input
              type="text"
              placeholder="Search for people by name or email..."
              value={searchTerm}
              onChange={handleSearchChange}
              className="search-input"
            />
            <button 
              className="filter-button"
              onClick={() => setShowFilters(!showFilters)}
            >
              <FontAwesomeIcon icon={faFilter} />
              <span>Filters</span>
            </button>
          </div>
          
          {showFilters && (
            <div className="filters-panel">
              <div className="filter-header">
                <h3>Refine your search</h3>
                <button onClick={clearFilters} className="clear-filters-btn">
                  Clear all
                </button>
              </div>
              
              <div className="filter-group">
                <div className="filter-item">
                  <label>
                    <FontAwesomeIcon icon={faBriefcase} />
                    <span>Name</span>
                  </label>
                  <input
                    type="text"
                    name="profession"
                    value={filters.profession}
                    onChange={handleFilterChange}
                    placeholder="e.g. John Doe"
                  />
                </div>
                
                <div className="filter-item">
                  <label>
                    <FontAwesomeIcon icon={faMapMarkerAlt} />
                    <span>Email</span>
                  </label>
                  <input
                    type="text"
                    name="location"
                    value={filters.location}
                    onChange={handleFilterChange}
                    placeholder="e.g. john@example.com"
                  />
                </div>
              </div>
              
              <button 
                className="close-filters"
                onClick={() => setShowFilters(false)}
              >
                <FontAwesomeIcon icon={faTimes} />
              </button>
            </div>
          )}
        </div>
      </div>
      
      <div className="search-results-container custom-scrollbar">
        <h2>People ({searchResults.length})</h2>
        
        {loading ? (
          <div className="loading-container">
            <div className="spinner"></div>
            <p>Loading users...</p>
          </div>
        ) : error ? (
          <div className="error-container">
            <p className="error-message">{error}</p>
          </div>
        ) : searchResults.length === 0 ? (
          <div className="no-results">
            <FontAwesomeIcon icon={faSearch} className="no-results-icon" />
            <h3>No results found</h3>
            <p>Try adjusting your search or filters to find what you're looking for.</p>
          </div>
        ) : (
          <div className="user-cards">
            {searchResults.map(user => (
              <div className="user-card" key={user.user_id || user.id}>
                <div className="user-card-header">
                  <img 
                    src={`https://i.pravatar.cc/150?u=${user.user_id || user.id}`} 
                    alt={user.fullname} 
                    className="user-avatar" 
                  />
                  <div className="user-info">
                    <h3>{user.fullname}</h3>
                    <p className="user-email">{user.email}</p>
                  </div>
                </div>
                
                <div className="user-actions">
                  {getConnectionButton(user.user_id || user.id)}
                  <button 
                    className="view-profile-button"
                    onClick={() => viewProfile(user.user_id || user.id)}
                  >
                    View Profile
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Searching;
