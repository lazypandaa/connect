import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../assets/css/Stories.css';
import { ensureValidToken } from '../utils/tokenValidator';

const Stories = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [friendshipStatuses, setFriendshipStatuses] = useState({});
  const [processingUsers, setProcessingUsers] = useState([]);
  const [nonFriends, setNonFriends] = useState([]);

  // Get user token from localStorage
  const token = localStorage.getItem('token');
  const currentUserId = localStorage.getItem('userId');
  
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get('http://localhost:8080/users/all');
        setUsers(response.data);
        
        // After getting users, check friendship status for each
        if (token && response.data.length > 0) {
          await checkFriendshipStatuses(response.data);
        }
        
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch users');
        setLoading(false);
        console.error('Error fetching users:', err);
      }
    };

    fetchUsers();
  }, [token]);

  useEffect(() => {
    // Filter users to show only those who are not friends
    if (users.length > 0 && Object.keys(friendshipStatuses).length > 0) {
      const filtered = users.filter(user => {
        // Skip current user
        if (user.user_id.toString() === currentUserId) return false;
        
        const status = friendshipStatuses[user.user_id];
        // Include users who are not friends (no status or status is not 'accepted')
        return !status || status.status !== 'accepted';
      });
      
      setNonFriends(filtered);
    } else if (users.length > 0) {
      // If we don't have friendship statuses yet, exclude only the current user
      setNonFriends(users.filter(user => user.user_id.toString() !== currentUserId));
    }
  }, [users, friendshipStatuses, currentUserId]);

  const checkFriendshipStatuses = async (usersList) => {
    const statuses = {};
    
    for (const user of usersList) {
      // Skip checking friendship with self
      if (user.user_id.toString() === currentUserId) continue;
      
      try {
        const response = await axios.post('http://localhost:8080/friends/check-status', {
          csrid: token,
          otherUserId: user.user_id
        });
        
        if (response.data.status === 'success') {
          statuses[user.user_id] = {
            status: response.data.friendshipStatus,
            requestSent: response.data.requestSent
          };
        }
      } catch (err) {
        console.error(`Error checking friendship status for user ${user.user_id}:`, err);
      }
    }
    
    setFriendshipStatuses(statuses);
  };
  
  const handleConnect = async (userId) => {
    if (!token) {
      alert('You must be logged in to connect with users');
      return;
    }
    
    // First, validate the token
    if (!await ensureValidToken()) {
      return; // ensureValidToken handles the alerts and redirects
    }
    
    // Set processing state
    setProcessingUsers(prev => [...prev, userId]);
    
    try {
      console.log("Sending friend request to user ID:", userId);
      console.log("Using token:", token.substring(0, 15) + "...");

      // Create axios instance with timeout
      const axiosInstance = axios.create({
        timeout: 10000 // 10 seconds
      });
      
      const response = await axiosInstance.post('http://localhost:8080/friends/send-request', {
        csrid: token,
        receiverId: userId
      });
      
      console.log("Friend request response:", response.data);
      
      if (response.data.status === 'success') {
        // Update friendship status locally
        setFriendshipStatuses(prev => ({
          ...prev,
          [userId]: { 
            status: 'pending',
            requestSent: true
          }
        }));
        alert("Friend request sent successfully!");
      } else {
        alert(response.data.message || 'Failed to send friend request');
      }
    } catch (err) {
      console.error('Error sending friend request:', err);
      
      // More detailed error logging
      if (err.response) {
        console.error("Response data:", err.response.data);
        console.error("Response status:", err.response.status);
      } else if (err.request) {
        console.error("Request was made but no response received");
      }
      
      // Suggest specific solutions based on error
      if (err.code === 'ECONNABORTED') {
        alert('Request timed out. Please check your connection and try again.');
      } else if (err.response && err.response.status === 401) {
        alert('Your session has expired. Please log in again.');
        // Optionally redirect to login
        localStorage.removeItem('token');
      } else {
        alert('Failed to send friend request. Please refresh the page and try again.');
      }
    } finally {
      // Remove from processing state
      setProcessingUsers(prev => prev.filter(id => id !== userId));
    }
  };
  
  const getButtonText = (userId) => {
    if (processingUsers.includes(userId)) {
      return '...';
    }
    
    const status = friendshipStatuses[userId];
    if (!status) return 'Connect';
    
    switch(status.status) {
      case 'accepted':
        return 'Connected';
      case 'pending':
        return status.requestSent ? 'Request Sent' : 'Accept Request';
      case 'rejected':
        return 'Connect';
      case 'blocked':
        return 'Blocked';
      default:
        return 'Connect';
    }
  };
  
  const getButtonClass = (userId) => {
    const status = friendshipStatuses[userId];
    if (!status) return 'connect-btn';
    
    switch(status.status) {
      case 'accepted':
        return 'connect-btn connected';
      case 'pending':
        return 'connect-btn pending';
      case 'blocked':
        return 'connect-btn blocked';
      default:
        return 'connect-btn';
    }
  };
  
  const isButtonDisabled = (userId) => {
    if (processingUsers.includes(userId)) return true;
    
    const status = friendshipStatuses[userId];
    if (!status) return false;
    
    return ['accepted', 'blocked'].includes(status.status) || 
           (status.status === 'pending' && status.requestSent);
  };

  return (
    <div className="stories-container">
      <div className="stories-header">
        <h3>People You May Know</h3>
      </div>
      <div className="stories-list custom-scrollbar">
        {loading ? (
          <p>Loading users...</p>
        ) : error ? (
          <p className="error-message">{error}</p>
        ) : nonFriends.length === 0 ? (
          <p>No new people to connect with</p>
        ) : (
          nonFriends.map((user) => (
            <div key={user.user_id} className="story-item">
              <div className="story-avatar-container">
                <img 
                  src={`https://ui-avatars.com/api/?name=${encodeURIComponent(user.fullname || 'User')}&background=random`} 
                  alt={user.fullname} 
                  className="story-avatar" 
                />
              </div>
              <div className="story-info">
                <div className="username-connect-wrapper">
                  <p className="story-username">{user.fullname || 'Unknown User'}</p>
                  <button 
                    className={getButtonClass(user.user_id)}
                    onClick={() => handleConnect(user.user_id)}
                    disabled={isButtonDisabled(user.user_id)}
                  >
                    {getButtonText(user.user_id)}
                  </button>
                </div>
                <p className="story-timestamp">{user.email}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Stories;
