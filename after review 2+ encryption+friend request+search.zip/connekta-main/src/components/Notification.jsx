import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaBell, FaCheck, FaTimes, FaUserPlus, FaUserCheck } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

function Notification() {
  const [notifications, setNotifications] = useState([]);
  const [friendRequests, setFriendRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchNotifications();
    fetchFriendRequests();
  }, []);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      
      if (!token) {
        setError("Please log in to view notifications");
        setLoading(false);
        return;
      }

      // In a real implementation, you would fetch from your API
      // For now, we're using static data
      setNotifications([
        { id: 1, type: 'message', text: 'You have a new message from John Doe', isRead: false },
        { id: 2, type: 'profile', text: 'Your profile was updated successfully', isRead: true },
        { id: 3, type: 'follower', text: 'You have a new follower: Jane Smith', isRead: false }
      ]);
      
      setLoading(false);
    } catch (err) {
      console.error("Error fetching notifications:", err);
      setError("Failed to load notifications");
      setLoading(false);
    }
  };

  const fetchFriendRequests = async () => {
    try {
      const token = localStorage.getItem('token');
      
      if (!token) {
        return;
      }

      const response = await axios.post(
        'http://localhost:8080/friends/pending-requests',
        { csrid: token }
      );
      
      if (response.data.status === 'success') {
        setFriendRequests(response.data.requests || []);
      } else {
        console.error("Failed to fetch friend requests:", response.data.message);
      }
    } catch (err) {
      console.error("Error fetching friend requests:", err);
    }
  };

  const handleAcceptFriendRequest = async (requestId) => {
    try {
      const token = localStorage.getItem('token');
      
      if (!token) {
        return;
      }

      // Log details for debugging
      console.log("Accepting friend request with ID:", requestId);
      console.log("Using token:", token.substring(0, 15) + "...");

      const response = await axios.post(
        'http://localhost:8080/friends/accept-request',
        { csrid: token, requestId: requestId }
      );
      
      console.log("Accept request response:", response.data);
      
      if (response.data.status === 'success') {
        // Remove the request from the list
        setFriendRequests(prevRequests => 
          prevRequests.filter(request => request.id !== requestId)
        );
        
        // Add a success notification
        alert("Friend request accepted successfully!");
        
        // Navigate to the friends page
        navigate('/friends');
      } else {
        console.error("Failed to accept friend request:", response.data.message);
      }
    } catch (err) {
      console.error("Error accepting friend request:", err);
      // More detailed error logging
      if (err.response) {
        console.error("Response data:", err.response.data);
        console.error("Response status:", err.response.status);
      }
    }
  };

  const handleRejectFriendRequest = async (requestId) => {
    try {
      const token = localStorage.getItem('token');
      
      if (!token) {
        return;
      }

      const response = await axios.post(
        'http://localhost:8080/friends/reject-request',
        { csrid: token, requestId: requestId }
      );
      
      if (response.data.status === 'success') {
        // Remove the request from the list
        setFriendRequests(prevRequests => 
          prevRequests.filter(request => request.id !== requestId)
        );
      } else {
        console.error("Failed to reject friend request:", response.data.message);
      }
    } catch (err) {
      console.error("Error rejecting friend request:", err);
    }
  };

  return (
    <div>
      <h6 className='text-xl font-bold flex mb-4'>Notifications:</h6>
      
      {/* Friend Requests Section */}
      {friendRequests.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Friend Requests</h2>
          <div className='flex flex-col gap-3'>
            {friendRequests.map((request) => (
              <div key={request.id} className='bg-blue-50 p-4 rounded-lg shadow-md border border-blue-100'>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full bg-gray-300 overflow-hidden mr-3">
                      <img 
                        src={`https://i.pravatar.cc/150?u=${request.sender.id}`} 
                        alt={request.sender.fullname} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <p className='text-sm font-medium'>{request.sender.fullname} sent you a friend request</p>
                      <p className='text-xs text-gray-500'>
                        {new Date(request.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => handleAcceptFriendRequest(request.id)}
                      className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-sm flex items-center"
                    >
                      <FaUserCheck className="mr-1" />
                      Accept
                    </button>
                    <button 
                      onClick={() => handleRejectFriendRequest(request.id)}
                      className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded text-sm"
                    >
                      Decline
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Regular Notifications */}
      <div className='flex flex-col gap-2'>
        {loading ? (
          <p className="text-center text-gray-500">Loading notifications...</p>
        ) : error ? (
          <p className="text-center text-red-500">{error}</p>
        ) : notifications.length === 0 ? (
          <p className="text-center text-gray-500">No notifications</p>
        ) : (
          notifications.map(notification => (
            <div 
              key={notification.id} 
              className={`bg-gray-200 p-3 rounded-lg shadow-md ${!notification.isRead ? 'border-l-4 border-blue-500' : ''}`}
            >
              <p className='text-sm'>{notification.text}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default Notification;