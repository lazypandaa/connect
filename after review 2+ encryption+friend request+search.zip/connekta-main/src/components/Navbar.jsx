// Assuming you have a Navbar.jsx file - add this import
import NotificationBadge from './NotificationBadge';

// In your Navbar component, add the NotificationBadge
<div className="flex items-center gap-4">
  <NotificationBadge />
  {/* Other navigation items */}
</div>
