/**
 * Token validation utility to help diagnose token issues
 */
export const validateLocalToken = () => {
  const token = localStorage.getItem('token');
  
  if (!token) {
    console.error("No token found in localStorage");
    return {
      isValid: false,
      error: "No token found"
    };
  }
  
  // Check token format (usually JWT tokens have 3 parts separated by dots)
  const parts = token.split('.');
  if (parts.length !== 3) {
    console.error("Token format is invalid, expected 3 parts but got", parts.length);
    return {
      isValid: false,
      error: "Invalid token format"
    };
  }
  
  try {
    // Try to decode the token payload
    const payload = JSON.parse(atob(parts[1]));
    
    // Check if token is expired
    const currentTime = Math.floor(Date.now() / 1000);
    if (payload.exp && payload.exp < currentTime) {
      console.error("Token has expired at", new Date(payload.exp * 1000));
      return {
        isValid: false,
        error: "Token expired",
        expiry: new Date(payload.exp * 1000)
      };
    }
    
    return {
      isValid: true,
      payload: payload
    };
  } catch (err) {
    console.error("Error decoding token:", err);
    return {
      isValid: false,
      error: "Error decoding token"
    };
  }
};

/**
 * Use this function to check the token before making requests
 */
export const ensureValidToken = async (callback) => {
  const tokenStatus = validateLocalToken();
  
  if (!tokenStatus.isValid) {
    // Token is invalid, alert the user and redirect to login
    alert(`Your session has expired or is invalid. Please log in again.\n${tokenStatus.error}`);
    
    // Clear the invalid token
    localStorage.removeItem('token');
    
    // Redirect to login
    window.location.href = '/login';
    return false;
  }
  
  // Token looks valid, proceed with the callback
  if (callback && typeof callback === 'function') {
    return await callback();
  }
  
  return true;
};
