import React, { useState } from 'react';
import './../assets/css/LoginPage.css';
import leftImage from './../assets/images/connekta+IconLogoTagline.png';
import connecta from './../assets/images/connekta logo.png';
import { callApi } from '../api';

const SignupPage = ({ onSignUpSuccess }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSignup = async (e) => {
    e.preventDefault();

    // Check if passwords match
    if (formData.password !== formData.confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    const data = JSON.stringify({
      fullname: formData.fullName,
      email: formData.email,
      password: formData.password,
    });

    console.log("Request Payload:", data); // Log the request payload

    callApi("POST", "http://localhost:8080/users/signup", data, getResponse)
      .then((response) => {
        console.log("Response:", response); // Log the response
      })
      .catch((error) => {
        console.error("Error:", error); // Log any errors
      });
  };
  const getResponse = (res) => {
    alert(res);
  };

  return (
    <div className="login-page">
      <div className="left-bar">
        <img src={leftImage} alt="Connekta" />
      </div>

      <div className="login-container">
        <div className="flex justify-center items-center">
          <img className="w-10 h-10" src={connecta} alt="Connekta" />
        </div>

        <input
          type="text"
          name="fullName"
          placeholder="Full Name"
          value={formData.fullName}
          onChange={handleChange}
          id="fullname"
          required
        />
        <input
          type="email"
          name="email"
          placeholder="E-Mail"
          value={formData.email}
          onChange={handleChange}
          id="email"
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          id="passwordsignup"
          required
        />
        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirm Password"
          value={formData.confirmPassword}
          onChange={handleChange}
          id="passwordsignup_confirm"
          required
        />
        <div className="button-group">
          <button className="signup-button" onClick={handleSignup}>Sign Up</button>
        </div>
      </div>
    </div>
  );
};

export default SignupPage;
