import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./../assets/css/Header.css";
import Notification from "./../components/Notification";
import ThemeToggle from "./ThemeToggle"; // Import the ThemeToggle component
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faHome,
  faSearch,
  faCompass,
  faBell,
  faUser,
  faBars,
  faComments,
} from "@fortawesome/free-solid-svg-icons";
import connektaLogo from "./../assets/images/connekta logo.png";
import connektaText from "./../assets/images/connekta just text.png";

const Header = () => {
  const navigate = useNavigate(); // Create navigate function
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);

  const handleMouseEnter = () => {
    setIsDropdownVisible(true);
  };

  const handleMouseLeave = () => {
    setIsDropdownVisible(false);
  };

  return (
    <header className="header">
      <div className="flex gap-1 items-center">
        <img
          src={connektaLogo}
          alt="Connekta Logo"
          className="logo w-10 h-10"
        />
        <img
          src={connektaText}
          alt="Connekta Text"
          className="logo-text w-25 h-10 pb-1"
        />
      </div>
      <nav className="navbuttons">
        <ul className="flex flex-row space-x-4">
          <li
            className="flex flex-col items-center cursor-pointer"
            onClick={() => navigate("/")} // Redirect to home page on click
          >
            <FontAwesomeIcon icon={faHome} className="mb-1" />
            <p className="m-0">Home</p>
          </li>
          <li className="flex flex-col items-center">
            <Link
              className="flex-col gap-0 items-center justify-center"
              to="/search"
            >
              <FontAwesomeIcon icon={faSearch} className="mb-1" />
              <p className="m-0">Search</p>
            </Link>
          </li>
          <li
            className="flex flex-col items-center relative"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            <FontAwesomeIcon icon={faBell} className="mb-1" />
            <p className="m-0">Notifications</p>
            {isDropdownVisible && (
              <div className="dropdown">
                <Notification />
              </div>
            )}
          </li>
          <li className="flex flex-col items-center">
            <FontAwesomeIcon icon={faCompass} className="mb-1" />
            <p className="m-0">Explore</p>
          </li>
          <li className="flex flex-col items-center">
            <Link
              className="flex-col gap-0 items-center justify-center"
              to="/chatpage"
            >
              <FontAwesomeIcon icon={faComments} className="mb-1" />
              <p className="m-0">Chat</p>
            </Link>
          </li>
          <li className="flex flex-col items-center">
            <Link
              className="flex-col gap-0 items-center justify-center"
              to="/ProfilePage"
            >
              <FontAwesomeIcon icon={faUser} className="pl-3" />
              <p className="">Profile</p>
            </Link>
          </li>
          {/* Add Theme Toggle */}
          <li className="flex flex-col items-center">
            <ThemeToggle />
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
