import React, { useState, useRef } from "react";
import { FaImage, FaVideo, FaSmile, FaMapMarkerAlt, FaPoll, FaEllipsisH, FaTimes, FaTimesCircle } from "react-icons/fa";
import { motion, AnimatePresence } from "framer-motion";
import "././../assets/css/Trending.css";

const PostingComponent = () => {
  const [postText, setPostText] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [showPostingInterface, setShowPostingInterface] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const fileInputRef = useRef(null);
  
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Post submitted:", postText, selectedImage);
    setPostText("");
    setSelectedImage(null);
    setExpanded(false);
    setShowPostingInterface(false);
  };

  const expandTextarea = () => {
    setExpanded(true);
  };

  const showPostInterface = () => {
    setShowPostingInterface(true);
  };
  
  const handlePhotoClick = () => {
    fileInputRef.current.click();
  };
  
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage({
        file,
        preview: URL.createObjectURL(file)
      });
      setExpanded(true);
    }
  };
  
  const removeImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="posting-wrapper">
      {!showPostingInterface && (
        <motion.div 
          className="fake-input-container"
          onClick={showPostInterface}
          whileHover={{ boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)" }}
        >
          <div className="fake-input-avatar">
            <img 
              src="https://i.pravatar.cc/150?img=32" 
              alt="User profile"
            />
          </div>
          <div className="fake-input">
            What's on your mind, John?
          </div>
        </motion.div>
      )}

      <AnimatePresence>
        {showPostingInterface && (
          <motion.div 
            className="posting-container"
            initial={{ opacity: 0, y: -20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
          >
            <div className="posting-header">
              <motion.h3 
                whileHover={{ scale: 1.03 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                Share your thoughts
              </motion.h3>
              <motion.button 
                className="close-button"
                onClick={() => setShowPostingInterface(false)}
                whileHover={{ scale: 1.2, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
              >
                <FaTimes />
              </motion.button>
            </div>
            
            <div className="post-content">
              <div className="user-profile">
                <div className="avatar-wrapper">
                  <img 
                    src="https://i.pravatar.cc/150?img=32" 
                    alt="User profile"
                    className="user-avatar" 
                  />
                  <span className="status-indicator"></span>
                </div>
                <div className="post-context">
                  <span className="username">John Doe</span>
                  <div className="privacy-selector">
                    <span>Public</span>
                    <svg viewBox="0 0 20 20" width="16" height="16">
                      <path d="M5 8l5 5 5-5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </div>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="input-wrapper" onClick={expandTextarea}>
                  <textarea 
                    className={`post-input ${expanded ? 'expanded' : ''}`}
                    placeholder={expanded ? "What would you like to share today?" : "What's on your mind, John?"}
                    value={postText}
                    onChange={(e) => setPostText(e.target.value)}
                    autoFocus
                  />
                  {postText.length > 0 && (
                    <motion.div 
                      className="emoji-suggestion"
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.2 }}
                    >
                      <span role="img" aria-label="suggested emoji">😊</span>
                      <span role="img" aria-label="suggested emoji">❤️</span>
                      <span role="img" aria-label="suggested emoji">👍</span>
                    </motion.div>
                  )}
                </div>
                
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  style={{ display: 'none' }}
                />
                
                {selectedImage && (
                  <motion.div 
                    className="media-preview"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="image-preview-container">
                      <img 
                        src={selectedImage.preview}
                        alt="Selected preview"
                        className="image-preview"
                      />
                      <button
                        type="button"
                        className="remove-image-btn"
                        onClick={removeImage}
                      >
                        <FaTimesCircle />
                      </button>
                    </div>
                    <div className="image-name">
                      {selectedImage.file.name.length > 25 
                        ? selectedImage.file.name.substring(0, 22) + '...' 
                        : selectedImage.file.name}
                    </div>
                  </motion.div>
                )}
                
                <div className="post-options-container">
                  <div className="add-to-post">
                    <div className="options-label">Add to your post</div>
                    <div className="post-options">
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn photo"
                        onClick={handlePhotoClick}
                      >
                        <FaImage />
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn video"
                      >
                        <FaVideo />
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn feeling"
                      >
                        <FaSmile />
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn location"
                      >
                        <FaMapMarkerAlt />
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn poll"
                      >
                        <FaPoll />
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        type="button" 
                        className="option-btn more"
                      >
                        <FaEllipsisH />
                      </motion.button>
                    </div>
                  </div>
                </div>
                
                <motion.button 
                  type="submit" 
                  className={`post-button ${(postText.length > 0 || selectedImage) ? 'active' : ''}`}
                  disabled={postText.length === 0 && !selectedImage}
                  whileHover={{ scale: (postText.length > 0 || selectedImage) ? 1.02 : 1 }}
                  whileTap={{ scale: (postText.length > 0 || selectedImage) ? 0.98 : 1 }}
                >
                  Share Now
                </motion.button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PostingComponent;
