import React, { useContext } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMoon, faSun } from '@fortawesome/free-solid-svg-icons';
import { ThemeContext } from '../context/ThemeContext';
import '../assets/css/ThemeToggle.css';

const ThemeToggle = () => {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const isDarkMode = theme === 'dark';

  return (
    <button 
      onClick={toggleTheme} 
      className="theme-toggle-btn"
      aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
    >
      <FontAwesomeIcon 
        icon={isDarkMode ? faSun : faMoon} 
        className="theme-icon" 
      />
    </button>
  );
};

export default ThemeToggle;
