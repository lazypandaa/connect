import React, { useState } from "react";
import "./../assets/css/LoginPage.css";
import leftImage from "./../assets/images/connekta+IconLogoTagline.png";
import connecta from "./../assets/images/connekta logo.png";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const LoginPage = ({ onLogin }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      console.log("Attempting login with:", formData);

      const response = await axios.post(
        "http://localhost:8080/users/signin",
        formData,
        {
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          withCredentials: true,
        }
      );

      console.log("Full server response:", response);

      // Check if we have a response with data
      if (response && response.data) {
        console.log("Response data received:", response.data);

        // Check for token in different possible locations
        const token = response.data;

        if (token) {
          console.log("Token received successfully");

          // Store token
          localStorage.setItem("token", token);

          // Store user data including username/email
          localStorage.setItem("userEmail", formData.email);

          // If response contains user's name, store it as well
          if (response.data.user && response.data.user.fullname) {
            localStorage.setItem("userName", response.data.user.fullname);
          } else if (
            response.data.data &&
            response.data.data.user &&
            response.data.data.user.fullname
          ) {
            localStorage.setItem("userName", response.data.data.user.fullname);
          } else {
            // If no name available, use the email as username (before the @ symbol)
            const emailUsername = formData.email.split("@")[0];
            localStorage.setItem("userName", emailUsername);
          }

          // Store user data if available
          if (response.data.user) {
            localStorage.setItem("user", JSON.stringify(response.data.user));
          } else if (response.data.data && response.data.data.user) {
            localStorage.setItem(
              "user",
              JSON.stringify(response.data.data.user)
            );
          }

          // Set the token in axios default headers for future requests
          axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;

          // Call the onLogin callback from App.jsx to update state
          if (onLogin) {
            onLogin();
          }

          // Redirect to dashboard or home page
          navigate("/");
        } else {
          console.error("Token not found in response:", response.data);
          setError("Authentication failed: Token not received");
        }
      } else {
        console.error("Invalid response structure:", response);
        setError("Invalid response from server");
      }
    } catch (error) {
      console.error("Login error details:", error);
      if (error.response) {
        // Server responded with an error
        console.error("Server error response:", error.response);
        setError(
          error.response.data?.message ||
            error.response.data ||
            "Invalid email or password"
        );
      } else if (error.request) {
        // Request was made but no response received
        console.error("No response received:", error.request);
        setError("No response from server. Please try again.");
      } else {
        // Error in request setup
        console.error("Request setup error:", error.message);
        setError("An error occurred. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="left-bar">
        <img src={leftImage} alt="Connekta" />
      </div>
      <div className="login-container">
        <div className="flex justify-center items-center">
          <img className="w-10 h-10" src={connecta} alt="Connekta" />
        </div>
        {error && <div className="error-message">{error}</div>}
        <form onSubmit={handleLogin}>
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            id="email"
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            id="password"
            required
          />
          <div className="button-group">
            <button type="submit" disabled={loading}>
              {loading ? "Signing in..." : "Login"}
            </button>
            <button type="button" className="signup-button">
              <Link to="/signup">Sign Up</Link>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;